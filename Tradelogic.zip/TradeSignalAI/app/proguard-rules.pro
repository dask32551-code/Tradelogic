# Keep Room entities
-keep class com.tradesignal.ai.data.local.entity.** { *; }

# Keep models
-keep class com.tradesignal.ai.data.model.** { *; }
-keep class com.tradesignal.ai.domain.** { *; }

# Gson
-keepattributes Signature
-keepattributes *Annotation*
-dontwarn sun.misc.**
-keep class com.google.gson.** { *; }
-keep class * implements com.google.gson.TypeAdapter
-keep class * implements com.google.gson.TypeAdapterFactory
-keep class * implements com.google.gson.JsonSerializer
-keep class * implements com.google.gson.JsonDeserializer
