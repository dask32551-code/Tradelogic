package com.tradesignal.ai

import com.tradesignal.ai.data.remote.YahooFinanceClient
import com.tradesignal.ai.data.remote.YahooSymbols
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.IOException

class YahooFinanceClientTest {

    @Test
    fun symbolMapping() {
        assertEquals("^NSEI", YahooSymbols.toYahoo("NIFTY"))
        assertEquals("^NSEBANK", YahooSymbols.toYahoo("BANKNIFTY"))
        assertEquals("^BSESN", YahooSymbols.toYahoo("SENSEX"))
        assertEquals("RELIANCE.NS", YahooSymbols.toYahoo("reliance"))
        assertEquals("TCS.NS", YahooSymbols.toYahoo("TCS"))
    }

    @Test
    fun parseChart_skipsNullRows_andConvertsToMillis() {
        val json = """
            {"chart":{"result":[{"timestamp":[1700000000,1700086400,1700172800],
            "indicators":{"quote":[{
              "open":[100.0,null,102.0],"high":[101.0,null,104.0],
              "low":[99.0,null,101.0],"close":[100.5,null,103.0],
              "volume":[1000,null,2000]}]}}],"error":null}}
        """.trimIndent()
        val candles = YahooFinanceClient.parseChart(json)
        assertEquals(2, candles.size)
        assertEquals(1700000000_000L, candles[0].timestamp)
        assertEquals(103.0, candles[1].close, 0.0001)
        assertEquals(2000.0, candles[1].volume, 0.0001)
    }

    @Test
    fun parseChart_errorThrows() {
        val json = """{"chart":{"result":null,"error":{"code":"Not Found","description":"No data found"}}}"""
        try {
            YahooFinanceClient.parseChart(json)
            assertTrue("expected IOException", false)
        } catch (e: IOException) {
            assertTrue(e.message!!.contains("No data found"))
        }
    }
}
