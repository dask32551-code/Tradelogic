package com.tradesignal.ai

import com.tradesignal.ai.domain.indicators.IndicatorCalculator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class IndicatorCalculatorTest {

    private val calc = IndicatorCalculator()

    @Test
    fun sma_simple() {
        val values = listOf(1.0, 2.0, 3.0, 4.0, 5.0)
        val result = calc.sma(values, 3)
        // padded then real
        assertTrue(result.size >= 3)
        assertEquals(2.0, result[2], 0.001) // (1+2+3)/3
        assertEquals(3.0, result[3], 0.001)
        assertEquals(4.0, result[4], 0.001)
    }

    @Test
    fun ema_does_not_crash_on_short_series() {
        val values = listOf(100.0, 101.0)
        val result = calc.ema(values, 9)
        assertTrue(result.isNotEmpty())
    }

    @Test
    fun rsi_bounds() {
        val closes = (1..50).map { 100.0 + it * 0.5 }
        val rsi = calc.rsi(closes, 14)
        assertTrue(rsi.isNotEmpty())
        assertTrue(rsi.last() in 0.0..100.0)
    }
}
