package com.tradesignal.ai.ui.screens.performance

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tradesignal.ai.TradeSignalApp
import com.tradesignal.ai.data.model.StrategyPerformance
import com.tradesignal.ai.ui.components.DemoBanner
import com.tradesignal.ai.ui.components.DisclaimerBanner
import com.tradesignal.ai.ui.theme.BuyGreen
import com.tradesignal.ai.ui.theme.CardDark
import com.tradesignal.ai.ui.theme.TextPrimary
import com.tradesignal.ai.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun PerformanceScreen(onBack: () -> Unit) {
    val app = TradeSignalApp.instance
    var loading by remember { mutableStateOf(true) }
    var performances by remember { mutableStateOf<List<StrategyPerformance>>(emptyList()) }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            performances = app.signalRepository.getPerformanceByStrategy()
            loading = false
        }
    }

    Column(Modifier.fillMaxSize()) {
        DemoBanner()
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
            }
            Text(
                "Strategy Performance",
                color = TextPrimary,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
        }

        if (loading) {
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator(color = BuyGreen)
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(
                        "Calculated from recorded signals & closed paper trades. Historical / simulated only.",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                if (performances.isEmpty()) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = CardDark), border = androidx.compose.foundation.BorderStroke(1.dp, com.tradesignal.ai.ui.theme.BorderDark), shape = RoundedCornerShape(12.dp)) {
                            Text(
                                "No closed trades yet. Generate setups and run backtests or paper trades to populate performance.",
                                color = TextSecondary,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                    }
                }
                items(performances) { p ->
                    Card(colors = CardDefaults.cardColors(containerColor = CardDark), border = androidx.compose.foundation.BorderStroke(1.dp, com.tradesignal.ai.ui.theme.BorderDark), shape = RoundedCornerShape(12.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(p.strategyName, color = TextPrimary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Stat("Trades", "${p.totalTrades}")
                            Stat("Wins / Losses", "${p.wins} / ${p.losses}")
                            Stat("Win Rate", "${"%.1f".format(p.winRate)}%")
                            Stat("Profit Factor", "%.2f".format(p.profitFactor))
                            Stat("Max Drawdown", "${"%.1f".format(p.maxDrawdownPercent)}%")
                            Stat("Net P&L", "%.2f".format(p.netPnl))
                        }
                    }
                }
                item {
                    DisclaimerBanner()
                    Spacer(Modifier.height(16.dp))
                }
            }
        }
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
        Text(value, color = TextPrimary, fontWeight = FontWeight.SemiBold)
    }
}
