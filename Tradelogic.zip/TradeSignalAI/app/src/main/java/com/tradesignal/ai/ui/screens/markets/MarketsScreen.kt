package com.tradesignal.ai.ui.screens.markets

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tradesignal.ai.TradeSignalApp
import com.tradesignal.ai.data.model.MarketQuote
import com.tradesignal.ai.ui.components.DemoBanner
import com.tradesignal.ai.ui.components.QuoteCard
import com.tradesignal.ai.ui.components.SectionHeader
import com.tradesignal.ai.ui.theme.BuyGreen
import com.tradesignal.ai.ui.theme.TextPrimary
import com.tradesignal.ai.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun MarketsScreen() {
    val app = TradeSignalApp.instance
    var quotes by remember { mutableStateOf<List<MarketQuote>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            quotes = app.marketDataRepository.getQuotes()
            loading = false
        }
    }

    Column(Modifier.fillMaxSize()) {
        DemoBanner()
        if (loading) {
            Column(
                Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CircularProgressIndicator(color = BuyGreen)
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text(
                        "Markets",
                        color = TextPrimary,
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        if (quotes.any { !it.isDemo }) "Delayed prices (Yahoo Finance) · Technical signals from local engine"
                        else "Demo prices · Technical signals from local engine",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(Modifier.height(8.dp))
                }
                item { SectionHeader("Indices") }
                items(quotes.filter { it.symbol in listOf("NIFTY", "BANKNIFTY", "SENSEX") }) {
                    QuoteCard(it)
                }
                item { SectionHeader("Stocks") }
                items(quotes.filter { it.symbol !in listOf("NIFTY", "BANKNIFTY", "SENSEX") }) {
                    QuoteCard(it)
                }
            }
        }
    }
}
