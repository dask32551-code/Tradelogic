package com.tradesignal.ai.domain.backtest

import com.tradesignal.ai.data.model.BacktestConfig
import com.tradesignal.ai.data.model.BacktestResult
import com.tradesignal.ai.data.model.Ohlcv
import com.tradesignal.ai.data.model.SignalType
import com.tradesignal.ai.data.model.SimulatedTrade
import com.tradesignal.ai.data.model.TradeResult
import com.tradesignal.ai.domain.engine.StrategyEngine
import com.tradesignal.ai.domain.indicators.IndicatorCalculator
import kotlin.math.abs

/**
 * Local backtesting engine.
 * Runs strategy on historical OHLCV and produces realistic simulated statistics.
 * All results are clearly historical / simulated.
 */
class BacktestEngine(
    private val calculator: IndicatorCalculator = IndicatorCalculator(),
    private val strategyEngine: StrategyEngine = StrategyEngine(calculator)
) {

    fun run(config: BacktestConfig, candles: List<Ohlcv>): BacktestResult {
        if (candles.size < 60) {
            return emptyResult(config)
        }

        val trades = mutableListOf<SimulatedTrade>()
        var i = 50 // warm-up

        while (i < candles.size - 5) {
            val window = candles.subList(0, i + 1)
            val setup = strategyEngine.analyze(
                config.symbol,
                config.symbol,
                window,
                config.timeframe,
                config.riskReward
            )

            if (setup != null && (setup.signal == SignalType.BUY || setup.signal == SignalType.SELL)) {
                // Simulate forward
                val entry = setup.entry
                val sl = setup.stopLoss
                val target = setup.target2
                var exitPrice = entry
                var exitIdx = i
                var result = TradeResult.EXPIRED
                var bars = 0

                for (j in (i + 1) until minOf(i + 40, candles.size)) {
                    val bar = candles[j]
                    bars++
                    if (setup.signal == SignalType.BUY) {
                        if (bar.low <= sl) {
                            exitPrice = sl
                            result = TradeResult.LOSS
                            exitIdx = j
                            break
                        }
                        if (bar.high >= target) {
                            exitPrice = target
                            result = TradeResult.WIN
                            exitIdx = j
                            break
                        }
                    } else {
                        if (bar.high >= sl) {
                            exitPrice = sl
                            result = TradeResult.LOSS
                            exitIdx = j
                            break
                        }
                        if (bar.low <= target) {
                            exitPrice = target
                            result = TradeResult.WIN
                            exitIdx = j
                            break
                        }
                    }
                    if (j == minOf(i + 39, candles.size - 1)) {
                        exitPrice = bar.close
                        result = if (setup.signal == SignalType.BUY) {
                            if (exitPrice > entry) TradeResult.WIN else if (exitPrice < entry) TradeResult.LOSS else TradeResult.BREAKEVEN
                        } else {
                            if (exitPrice < entry) TradeResult.WIN else if (exitPrice > entry) TradeResult.LOSS else TradeResult.BREAKEVEN
                        }
                        exitIdx = j
                    }
                }

                val pnl = when (setup.signal) {
                    SignalType.BUY -> exitPrice - entry
                    SignalType.SELL -> entry - exitPrice
                    else -> 0.0
                }

                trades.add(
                    SimulatedTrade(
                        entryTime = candles[i].timestamp,
                        exitTime = candles[exitIdx].timestamp,
                        direction = setup.signal,
                        entry = entry,
                        exit = exitPrice,
                        stopLoss = sl,
                        target = target,
                        pnl = pnl,
                        result = result,
                        barsHeld = bars
                    )
                )
                i = exitIdx + 1
            } else {
                i++
            }
        }

        return computeStats(config, trades)
    }

    private fun computeStats(config: BacktestConfig, trades: List<SimulatedTrade>): BacktestResult {
        val total = trades.size
        val wins = trades.count { it.result == TradeResult.WIN }
        val losses = trades.count { it.result == TradeResult.LOSS }
        val winRate = if (total > 0) wins.toDouble() / total * 100 else 0.0
        val avgWin = trades.filter { it.pnl > 0 }.map { it.pnl }.average().takeIf { !it.isNaN() } ?: 0.0
        val avgLoss = trades.filter { it.pnl < 0 }.map { it.pnl }.average().takeIf { !it.isNaN() } ?: 0.0
        val grossProfit = trades.filter { it.pnl > 0 }.sumOf { it.pnl }
        val grossLoss = abs(trades.filter { it.pnl < 0 }.sumOf { it.pnl })
        val pf = if (grossLoss > 0) grossProfit / grossLoss else if (grossProfit > 0) 99.0 else 0.0
        val net = trades.sumOf { it.pnl }

        var peak = 0.0
        var equity = 0.0
        var maxDd = 0.0
        trades.forEach {
            equity += it.pnl
            if (equity > peak) peak = equity
            val dd = if (peak > 0) (peak - equity) / peak * 100 else 0.0
            if (dd > maxDd) maxDd = dd
        }

        var maxConsecWin = 0
        var maxConsecLoss = 0
        var curWin = 0
        var curLoss = 0
        trades.forEach {
            if (it.result == TradeResult.WIN) {
                curWin++
                curLoss = 0
                if (curWin > maxConsecWin) maxConsecWin = curWin
            } else if (it.result == TradeResult.LOSS) {
                curLoss++
                curWin = 0
                if (curLoss > maxConsecLoss) maxConsecLoss = curLoss
            }
        }

        return BacktestResult(
            config = config,
            totalTrades = total,
            winningTrades = wins,
            losingTrades = losses,
            winRate = winRate,
            averageWin = avgWin,
            averageLoss = avgLoss,
            profitFactor = pf,
            maxDrawdownPercent = maxDd,
            netPnl = net,
            consecutiveWins = maxConsecWin,
            consecutiveLosses = maxConsecLoss,
            trades = trades
        )
    }

    private fun emptyResult(config: BacktestConfig) = BacktestResult(
        config = config,
        totalTrades = 0,
        winningTrades = 0,
        losingTrades = 0,
        winRate = 0.0,
        averageWin = 0.0,
        averageLoss = 0.0,
        profitFactor = 0.0,
        maxDrawdownPercent = 0.0,
        netPnl = 0.0,
        consecutiveWins = 0,
        consecutiveLosses = 0,
        trades = emptyList()
    )
}
