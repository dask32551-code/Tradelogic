package com.tradesignal.ai.ui.screens.profile

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tradesignal.ai.ui.components.DisclaimerBanner
import com.tradesignal.ai.ui.components.SectionHeader
import com.tradesignal.ai.ui.theme.BuyGreen
import com.tradesignal.ai.ui.theme.CardDark
import com.tradesignal.ai.ui.theme.TextPrimary
import com.tradesignal.ai.ui.theme.TextSecondary

@Composable
fun ProfileScreen(
    onNavigateToBacktest: () -> Unit,
    onNavigateToPerformance: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                "Profile & Settings",
                color = TextPrimary,
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                "Tradelogic · v1.0.0",
                color = TextSecondary,
                style = MaterialTheme.typography.bodyMedium
            )
        }

        item { SectionHeader("Tools") }
        item {
            MenuCard("Backtesting", "Run strategies on historical demo data") { onNavigateToBacktest() }
        }
        item {
            MenuCard("Strategy Performance", "View calculated results from signals & backtests") { onNavigateToPerformance() }
        }

        item { SectionHeader("About") }
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardDark), border = androidx.compose.foundation.BorderStroke(1.dp, com.tradesignal.ai.ui.theme.BorderDark),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text(
                        "This app is an educational paper-trading and technical-analysis toolkit. " +
                                "All market data in this version is demo/simulated. " +
                                "No live brokerage connection. No real money.",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Free tier: limited watchlist & paper trades · Ads may appear outside active analysis.",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Premium (planned): more alerts, advanced strategies, no ads.",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        item { SectionHeader("Risk Disclaimer") }
        item { DisclaimerBanner() }
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardDark), border = androidx.compose.foundation.BorderStroke(1.dp, com.tradesignal.ai.ui.theme.BorderDark),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    "This app provides market analysis and simulated trading tools for informational and educational purposes. " +
                            "Trading involves substantial risk and losses are possible. " +
                            "Past or simulated performance does not guarantee future results. " +
                            "If offered as regulated investment advice, obtain appropriate professional/legal guidance under applicable Indian regulations.",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(16.dp)
                )
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun MenuCard(title: String, subtitle: String, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = CardDark), border = androidx.compose.foundation.BorderStroke(1.dp, com.tradesignal.ai.ui.theme.BorderDark),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = BuyGreen, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, color = TextSecondary, style = MaterialTheme.typography.bodySmall)
        }
    }
}
