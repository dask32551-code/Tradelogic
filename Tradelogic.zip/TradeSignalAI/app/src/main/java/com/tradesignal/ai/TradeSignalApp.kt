package com.tradesignal.ai

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.tradesignal.ai.data.local.AppDatabase
import com.tradesignal.ai.data.repository.MarketDataRepository
import com.tradesignal.ai.data.repository.PaperTradingRepository
import com.tradesignal.ai.data.repository.SignalRepository
import com.tradesignal.ai.data.repository.WatchlistRepository
import com.tradesignal.ai.domain.engine.StrategyEngine
import com.tradesignal.ai.domain.indicators.IndicatorCalculator
import com.tradesignal.ai.domain.paper.PaperTradingEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class TradeSignalApp : Application() {

    val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    lateinit var database: AppDatabase
        private set

    lateinit var marketDataRepository: MarketDataRepository
        private set

    lateinit var signalRepository: SignalRepository
        private set

    lateinit var paperTradingRepository: PaperTradingRepository
        private set

    lateinit var watchlistRepository: WatchlistRepository
        private set

    lateinit var indicatorCalculator: IndicatorCalculator
        private set

    lateinit var strategyEngine: StrategyEngine
        private set

    lateinit var paperTradingEngine: PaperTradingEngine
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        createNotificationChannels()

        database = AppDatabase.getInstance(this)
        indicatorCalculator = IndicatorCalculator()
        strategyEngine = StrategyEngine(indicatorCalculator)

        marketDataRepository = MarketDataRepository(this, database)
        signalRepository = SignalRepository(database, strategyEngine)
        paperTradingRepository = PaperTradingRepository(database)
        watchlistRepository = WatchlistRepository(database)
        paperTradingEngine = PaperTradingEngine(paperTradingRepository)

        // Seed demo data on first launch (fallback), then warm the Yahoo cache in background
        applicationScope.launch {
            marketDataRepository.ensureDemoData()
            paperTradingRepository.ensureAccount()
            marketDataRepository.getQuotes()
        }
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)

            val alertsChannel = NotificationChannel(
                CHANNEL_ALERTS,
                "Price & Signal Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications for price targets, stop loss, and new setups"
            }

            val generalChannel = NotificationChannel(
                CHANNEL_GENERAL,
                "General",
                NotificationManager.IMPORTANCE_DEFAULT
            )

            manager.createNotificationChannel(alertsChannel)
            manager.createNotificationChannel(generalChannel)
        }
    }

    companion object {
        const val CHANNEL_ALERTS = "tradesignal_alerts"
        const val CHANNEL_GENERAL = "tradesignal_general"

        lateinit var instance: TradeSignalApp
            private set
    }
}
