package com.tradesignal.ai.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tradesignal.ai.TradeSignalApp
import com.tradesignal.ai.data.model.MarketQuote
import com.tradesignal.ai.data.repository.MarketDataRepository.DataStatus
import com.tradesignal.ai.data.model.SignalType
import com.tradesignal.ai.data.model.TradeSetup
import com.tradesignal.ai.ui.theme.AccentBlue
import com.tradesignal.ai.ui.theme.AmberText
import com.tradesignal.ai.ui.theme.BorderDark
import com.tradesignal.ai.ui.theme.BuyBg
import com.tradesignal.ai.ui.theme.BuyGreen
import com.tradesignal.ai.ui.theme.CardDark
import com.tradesignal.ai.ui.theme.LossRed
import com.tradesignal.ai.ui.theme.ProfitGreen
import com.tradesignal.ai.ui.theme.SellBg
import com.tradesignal.ai.ui.theme.SellRed
import com.tradesignal.ai.ui.theme.SurfaceVariantDark
import com.tradesignal.ai.ui.theme.TextPrimary
import com.tradesignal.ai.ui.theme.TextSecondary
import com.tradesignal.ai.ui.theme.TextTertiary
import com.tradesignal.ai.ui.theme.WatchBg
import java.text.NumberFormat
import java.util.Locale

val MonoFont = FontFamily.Monospace

// ---------- Header / notes ----------

@Composable
fun AppHeader(title: String = "Tradelogic") {
    Column(Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                color = TextPrimary,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold
            )
            DemoPill()
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(BorderDark))
    }
}

@Composable
fun DemoPill() {
    val status by TradeSignalApp.instance.marketDataRepository.status.collectAsState()
    val label = when (status) {
        DataStatus.DELAYED -> "DELAYED"
        DataStatus.MIXED -> "PARTIAL LIVE"
        DataStatus.DEMO -> "DEMO DATA"
    }
    val tint = if (status == DataStatus.DELAYED) BuyGreen else AmberText
    val shape = RoundedCornerShape(6.dp)
    Box(
        modifier = Modifier
            .background(Color.White, shape)
            .border(1.dp, tint, shape)
            .padding(horizontal = 12.dp, vertical = 7.dp)
    ) {
        Text(
            text = label,
            color = tint,
            fontFamily = MonoFont,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = 1.sp
        )
    }
}

/** One-line source note that follows the current data source. */
@Composable
fun dataNoteText(): String {
    val status by TradeSignalApp.instance.marketDataRepository.status.collectAsState()
    return when (status) {
        DataStatus.DELAYED ->
            "Prices from Yahoo Finance, delayed by about 15 minutes. Not for live execution. " +
                "Scores rate how many indicators agree. They do not predict profit."
        DataStatus.MIXED ->
            "Some symbols show delayed Yahoo Finance prices, the rest are simulated demo data. " +
                "Scores rate how many indicators agree. They do not predict profit."
        DataStatus.DEMO ->
            "Demo data only. Could not reach Yahoo Finance, so prices are simulated. " +
                "Scores rate how many indicators agree. They do not predict profit."
    }
}

@Composable
fun NoteQuote(text: String, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(IntrinsicSize.Min)
    ) {
        Box(
            Modifier
                .width(3.dp)
                .fillMaxHeight()
                .background(AmberText)
        )
        Spacer(Modifier.width(14.dp))
        Text(
            text = text,
            color = TextSecondary,
            fontSize = 15.sp,
            lineHeight = 22.sp,
            modifier = Modifier.padding(vertical = 2.dp)
        )
    }
}

@Composable
fun DemoBanner() {
    NoteQuote(
        text = dataNoteText(),
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
    )
}

@Composable
fun DisclaimerBanner() {
    NoteQuote(
        text = "Trading involves substantial risk. Losses are possible. Signals are probabilistic. " +
            "Past or simulated performance does not guarantee future results.",
        modifier = Modifier.padding(vertical = 8.dp)
    )
}

// ---------- Building blocks ----------

@Composable
fun AppCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier.then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CardDark),
        border = BorderStroke(1.dp, BorderDark),
        content = content
    )
}

@Composable
fun SignalBadge(signal: SignalType, modifier: Modifier = Modifier) {
    val bg = when (signal) {
        SignalType.BUY -> BuyBg
        SignalType.SELL -> SellBg
        SignalType.WATCH -> WatchBg
        SignalType.NONE -> SurfaceVariantDark
    }
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bg)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(
            text = signal.displayName(),
            color = signal.color(),
            fontFamily = MonoFont,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun TagChip(text: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(SurfaceVariantDark)
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Text(
            text = text,
            color = TextSecondary,
            fontFamily = MonoFont,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun ScoreBadge(score: Int, modifier: Modifier = Modifier) {
    Row(modifier = modifier, verticalAlignment = Alignment.Bottom) {
        Text(
            text = "$score",
            color = TextPrimary,
            fontFamily = MonoFont,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "/100",
            color = TextTertiary,
            fontFamily = MonoFont,
            fontSize = 18.sp
        )
    }
}

@Composable
fun ScoreBar(score: Int, color: Color, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(50)
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(8.dp)
            .clip(shape)
            .background(SurfaceVariantDark)
    ) {
        Box(
            Modifier
                .fillMaxWidth(score.coerceIn(0, 100) / 100f)
                .fillMaxHeight()
                .clip(shape)
                .background(color)
        )
    }
}

@Composable
fun Sparkline(
    values: List<Double>,
    modifier: Modifier = Modifier,
    color: Color = AccentBlue
) {
    Canvas(modifier = modifier) {
        if (values.size < 2) return@Canvas
        val lo = values.minOrNull() ?: return@Canvas
        val hi = values.maxOrNull() ?: return@Canvas
        val range = if (hi - lo > 0.0) hi - lo else 1.0
        val stepX = size.width / (values.size - 1)
        val path = Path()
        values.forEachIndexed { i, v ->
            val x = i * stepX
            val y = (size.height - ((v - lo) / range * size.height)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(
            path = path,
            color = color,
            style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
}

// ---------- Cards ----------

@Composable
fun QuoteCard(
    quote: MarketQuote,
    onClick: (() -> Unit)? = null
) {
    AppCard(modifier = Modifier.fillMaxWidth(), onClick = onClick) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = quote.symbol,
                    color = TextPrimary,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = quote.name,
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = formatPrice(quote.price),
                    color = TextPrimary,
                    fontFamily = MonoFont,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = formatPercent(quote.changePercent),
                    color = if (quote.changePercent >= 0) ProfitGreen else LossRed,
                    fontFamily = MonoFont,
                    fontSize = 13.sp
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(horizontalAlignment = Alignment.End) {
                SignalBadge(quote.signal)
                Spacer(Modifier.height(4.dp))
                Text(
                    text = quote.trend.displayName().lowercase(),
                    color = quote.trend.color(),
                    fontFamily = MonoFont,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
fun SetupCard(
    setup: TradeSetup,
    onClick: (() -> Unit)? = null
) {
    val barColor = when (setup.signal) {
        SignalType.SELL -> SellRed
        SignalType.WATCH -> AmberText
        else -> BuyGreen
    }
    AppCard(modifier = Modifier.fillMaxWidth(), onClick = onClick) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = setup.symbol,
                    color = TextPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                Spacer(Modifier.width(8.dp))
                SignalBadge(setup.signal)
                Spacer(Modifier.width(6.dp))
                TagChip(setup.timeframe.label)
                Spacer(Modifier.width(6.dp))
                TagChip(setup.trend.displayName().lowercase())
                Spacer(Modifier.weight(1f))
                ScoreBadge(setup.setupScore)
            }
            Spacer(Modifier.height(12.dp))
            ScoreBar(setup.setupScore, barColor)
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                LevelItem("Entry", formatPrice(setup.entry))
                LevelItem("Stop Loss", formatPrice(setup.stopLoss), SellRed)
                LevelItem("Target 1", formatPrice(setup.target1), BuyGreen)
                LevelItem("Target 2", formatPrice(setup.target2), BuyGreen)
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(
                    text = "R:R 1:${"%.1f".format(setup.riskReward)}",
                    color = TextSecondary,
                    fontFamily = MonoFont,
                    fontSize = 12.sp
                )
                Text(
                    text = setup.strategyName,
                    color = TextSecondary,
                    fontFamily = MonoFont,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false).padding(horizontal = 8.dp)
                )
                Text(
                    text = "Risk: ${setup.riskLevel}",
                    color = TextSecondary,
                    fontFamily = MonoFont,
                    fontSize = 12.sp
                )
            }
            Spacer(Modifier.height(10.dp))
            Text(
                text = setup.reason,
                color = TextSecondary,
                style = MaterialTheme.typography.bodySmall,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun LevelItem(label: String, value: String, valueColor: Color = TextPrimary) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, color = TextTertiary, style = MaterialTheme.typography.labelSmall)
        Text(
            text = value,
            color = valueColor,
            fontFamily = MonoFont,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    subtitle: String? = null,
    valueColor: Color = TextPrimary,
    modifier: Modifier = Modifier
) {
    AppCard(modifier = modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 18.dp)) {
            Text(text = title, color = TextSecondary, fontSize = 15.sp)
            Spacer(Modifier.height(8.dp))
            Text(
                text = value,
                color = valueColor,
                fontFamily = MonoFont,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )
            if (subtitle != null) {
                Text(text = subtitle, color = TextSecondary, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
fun SectionHeader(title: String, action: String? = null, onAction: (() -> Unit)? = null) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 14.dp, bottom = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title.uppercase(),
            color = TextSecondary,
            fontFamily = MonoFont,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 1.5.sp
        )
        if (action != null && onAction != null) {
            Text(
                text = action,
                color = AccentBlue,
                fontSize = 16.sp,
                modifier = Modifier.clickable { onAction() }
            )
        }
    }
}

// ---------- Formatting ----------

fun formatPercent(p: Double): String = "${if (p >= 0) "+" else ""}${"%.2f".format(p)}%"

fun formatPrice(price: Double): String {
    return if (price >= 1000) {
        NumberFormat.getNumberInstance(Locale("en", "IN")).apply {
            maximumFractionDigits = 2
            minimumFractionDigits = 2
        }.format(price)
    } else {
        "%.2f".format(price)
    }
}

fun formatInr(amount: Double): String {
    val nf = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
    nf.minimumFractionDigits = 0
    nf.maximumFractionDigits = 2
    return nf.format(amount)
}
