package com.tradesignal.ai.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        OhlcvEntity::class,
        SignalEntity::class,
        WatchlistEntity::class,
        PaperAccountEntity::class,
        PaperPositionEntity::class,
        PaperTradeEntity::class,
        AlertEntity::class,
        UserSettingsEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun ohlcvDao(): OhlcvDao
    abstract fun signalDao(): SignalDao
    abstract fun watchlistDao(): WatchlistDao
    abstract fun paperAccountDao(): PaperAccountDao
    abstract fun paperPositionDao(): PaperPositionDao
    abstract fun paperTradeDao(): PaperTradeDao
    abstract fun alertDao(): AlertDao
    abstract fun settingsDao(): SettingsDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "tradesignal_ai.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
