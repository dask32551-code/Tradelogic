package com.tradesignal.ai.ui.theme

import androidx.compose.ui.graphics.Color

// Light "paper" palette
val BuyGreen = Color(0xFF1B7F37)
val SellRed = Color(0xFFC62828)
val WatchYellow = Color(0xFF8A5A00)
val NeutralGray = Color(0xFF6B7280)

val BuyBg = Color(0xFFE3F1E6)
val SellBg = Color(0xFFFBE4E4)
val WatchBg = Color(0xFFEFE6D6)

val AmberText = Color(0xFF8A5A00)

// Names kept from the old dark theme so every screen picks up the new look
val BackgroundDark = Color(0xFFFAFAF7)
val SurfaceDark = Color(0xFFFFFFFF)
val SurfaceVariantDark = Color(0xFFF0F0EB)
val CardDark = Color(0xFFFFFFFF)

val TextPrimary = Color(0xFF1A1A1A)
val TextSecondary = Color(0xFF5F646B)
val TextTertiary = Color(0xFF8A8F98)

val BorderDark = Color(0xFFE3E3DC)
val AccentBlue = Color(0xFF1A5FD0)
val AccentPurple = Color(0xFF6F42C1)
val ProfitGreen = Color(0xFF1B7F37)
val LossRed = Color(0xFFC62828)
