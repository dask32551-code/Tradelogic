package com.tradesignal.ai.domain.engine

import com.tradesignal.ai.data.model.IndicatorValues
import com.tradesignal.ai.data.model.Ohlcv
import com.tradesignal.ai.data.model.SignalType
import com.tradesignal.ai.data.model.Timeframe
import com.tradesignal.ai.data.model.TradeSetup
import com.tradesignal.ai.data.model.Trend
import com.tradesignal.ai.domain.indicators.IndicatorCalculator
import java.util.UUID
import kotlin.math.abs

/**
 * Modular multi-indicator strategy engine.
 * Generates BUY / SELL / WATCH based on confluence of conditions.
 * Score is a quality score (0-100), NOT a probability of profit.
 */
class StrategyEngine(
    private val calculator: IndicatorCalculator
) {

    data class ScoreBreakdown(
        val total: Int,
        val factors: List<Pair<String, Int>>
    )

    fun analyze(
        symbol: String,
        name: String,
        candles: List<Ohlcv>,
        timeframe: Timeframe,
        riskReward: Double = 2.0
    ): TradeSetup? {
        if (candles.size < 50) return null

        val indicators = calculator.calculateAll(candles)
        val last = candles.last()
        val price = last.close

        val breakdown = computeScore(price, indicators, candles)
        val score = breakdown.total

        val signal = when {
            score >= 70 -> SignalType.BUY
            score <= 30 -> SignalType.SELL
            score in 40..60 -> SignalType.WATCH
            else -> SignalType.NONE
        }

        if (signal == SignalType.NONE) return null

        val atr = indicators.atr ?: (price * 0.01)
        val (entry, sl, t1, t2) = computeLevels(
            signal, price, atr, indicators, candles, riskReward
        )

        val trend = determineTrend(indicators)
        val riskLevel = when {
            abs(entry - sl) / entry > 0.03 -> "High"
            abs(entry - sl) / entry > 0.015 -> "Medium"
            else -> "Low"
        }

        val reason = buildReason(signal, breakdown, indicators)

        return TradeSetup(
            id = UUID.randomUUID().toString(),
            symbol = symbol,
            name = name,
            timeframe = timeframe,
            signal = signal,
            entry = entry,
            stopLoss = sl,
            target1 = t1,
            target2 = t2,
            riskReward = riskReward,
            setupScore = score,
            strategyName = "Multi-Indicator Confluence",
            timestamp = System.currentTimeMillis(),
            reason = reason,
            indicators = indicators,
            trend = trend,
            riskLevel = riskLevel,
            isDemo = true
        )
    }

    fun computeScore(
        price: Double,
        ind: IndicatorValues,
        candles: List<Ohlcv>
    ): ScoreBreakdown {
        val factors = mutableListOf<Pair<String, Int>>()
        var score = 50 // neutral baseline

        // EMA trend structure (+/- 15)
        val emaBull = (ind.ema9 ?: 0.0) > (ind.ema20 ?: 0.0) &&
                (ind.ema20 ?: 0.0) > (ind.ema50 ?: 0.0)
        val emaBear = (ind.ema9 ?: 0.0) < (ind.ema20 ?: 0.0) &&
                (ind.ema20 ?: 0.0) < (ind.ema50 ?: 0.0)
        when {
            emaBull && price > (ind.ema20 ?: 0.0) -> {
                score += 15
                factors.add("EMA stack bullish + price above EMA20" to 15)
            }
            emaBear && price < (ind.ema20 ?: 0.0) -> {
                score -= 15
                factors.add("EMA stack bearish + price below EMA20" to -15)
            }
            else -> factors.add("EMA structure mixed" to 0)
        }

        // RSI (+/- 12)
        val rsi = ind.rsi ?: 50.0
        when {
            rsi in 45.0..65.0 && emaBull -> {
                score += 12
                factors.add("RSI healthy in bullish zone ($rsi%.1f)".format(rsi) to 12)
            }
            rsi in 35.0..55.0 && emaBear -> {
                score -= 12
                factors.add("RSI healthy in bearish zone ($rsi%.1f)".format(rsi) to -12)
            }
            rsi > 70 -> {
                score -= 8
                factors.add("RSI overbought ($rsi%.1f)" to -8)
            }
            rsi < 30 -> {
                score += 8
                factors.add("RSI oversold ($rsi%.1f)" to 8)
            }
            else -> factors.add("RSI neutral ($rsi%.1f)" to 0)
        }

        // MACD (+/- 12)
        val hist = ind.macdHistogram ?: 0.0
        val macdLine = ind.macdLine ?: 0.0
        when {
            hist > 0 && macdLine > 0 -> {
                score += 12
                factors.add("MACD positive & histogram rising" to 12)
            }
            hist < 0 && macdLine < 0 -> {
                score -= 12
                factors.add("MACD negative & histogram falling" to -12)
            }
            else -> factors.add("MACD mixed" to 0)
        }

        // Volume confirmation (+/- 10)
        val lastVol = candles.lastOrNull()?.volume ?: 0.0
        val avgVol = ind.volumeAvg ?: lastVol
        if (avgVol > 0) {
            if (lastVol > avgVol * 1.2) {
                score += 10
                factors.add("Volume above average (confirmation)" to 10)
            } else if (lastVol < avgVol * 0.7) {
                score -= 5
                factors.add("Volume below average (weak)" to -5)
            } else {
                factors.add("Volume average" to 0)
            }
        }

        // Price vs VWAP (+/- 8)
        ind.vwap?.let { vwap ->
            when {
                price > vwap * 1.002 -> {
                    score += 8
                    factors.add("Price above VWAP" to 8)
                }
                price < vwap * 0.998 -> {
                    score -= 8
                    factors.add("Price below VWAP" to -8)
                }
                else -> factors.add("Price near VWAP" to 0)
            }
        }

        // Bollinger position (+/- 5)
        ind.bbUpper?.let { upper ->
            ind.bbLower?.let { lower ->
                when {
                    price > upper -> {
                        score -= 5
                        factors.add("Price above upper Bollinger" to -5)
                    }
                    price < lower -> {
                        score += 5
                        factors.add("Price below lower Bollinger" to 5)
                    }
                    else -> factors.add("Price inside Bollinger" to 0)
                }
            }
        }

        // Clamp 0-100
        score = score.coerceIn(0, 100)
        return ScoreBreakdown(score, factors)
    }

    private fun computeLevels(
        signal: SignalType,
        price: Double,
        atr: Double,
        ind: IndicatorValues,
        candles: List<Ohlcv>,
        rr: Double
    ): LevelSet {
        return when (signal) {
            SignalType.BUY -> {
                val sl = calculator.recentSwingLow(candles, 8)
                    ?: (price - atr * 1.5)
                val risk = price - sl
                val t1 = price + risk * (rr * 0.6)
                val t2 = price + risk * rr
                LevelSet(price, sl, t1, t2)
            }
            SignalType.SELL -> {
                val sl = calculator.recentSwingHigh(candles, 8)
                    ?: (price + atr * 1.5)
                val risk = sl - price
                val t1 = price - risk * (rr * 0.6)
                val t2 = price - risk * rr
                LevelSet(price, sl, t1, t2)
            }
            else -> {
                LevelSet(price, price * 0.99, price * 1.01, price * 1.02)
            }
        }
    }

    private fun determineTrend(ind: IndicatorValues): Trend {
        val e9 = ind.ema9 ?: return Trend.SIDEWAYS
        val e20 = ind.ema20 ?: return Trend.SIDEWAYS
        val e50 = ind.ema50 ?: return Trend.SIDEWAYS
        return when {
            e9 > e20 && e20 > e50 -> Trend.BULLISH
            e9 < e20 && e20 < e50 -> Trend.BEARISH
            else -> Trend.SIDEWAYS
        }
    }

    private fun buildReason(
        signal: SignalType,
        breakdown: ScoreBreakdown,
        ind: IndicatorValues
    ): String {
        val parts = mutableListOf<String>()
        parts.add("${signal.displayName()} setup (quality score ${breakdown.total}/100).")
        breakdown.factors.filter { it.second != 0 }.take(4).forEach {
            parts.add(it.first)
        }
        ind.rsi?.let { parts.add("RSI: ${"%.1f".format(it)}") }
        return parts.joinToString(" ")
    }

    private data class LevelSet(
        val entry: Double,
        val stopLoss: Double,
        val target1: Double,
        val target2: Double
    )
}
