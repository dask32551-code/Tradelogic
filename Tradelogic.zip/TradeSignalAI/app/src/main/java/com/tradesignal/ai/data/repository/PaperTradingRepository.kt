package com.tradesignal.ai.data.repository

import com.tradesignal.ai.data.local.AppDatabase
import com.tradesignal.ai.data.local.PaperAccountEntity
import com.tradesignal.ai.data.local.PaperPositionEntity
import com.tradesignal.ai.data.local.PaperTradeEntity
import com.tradesignal.ai.data.model.PaperAccount
import com.tradesignal.ai.data.model.PaperPosition
import com.tradesignal.ai.data.model.PaperTrade
import com.tradesignal.ai.data.model.SignalType
import com.tradesignal.ai.data.model.TradeResult
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map

class PaperTradingRepository(private val db: AppDatabase) {

    suspend fun ensureAccount() {
        if (db.paperAccountDao().getAccountOnce() == null) {
            db.paperAccountDao().insert(PaperAccountEntity())
        }
    }

    fun observeAccount(): Flow<PaperAccount?> {
        return combine(
            db.paperAccountDao().getAccount(),
            db.paperPositionDao().getAll(),
            db.paperTradeDao().getAll()
        ) { acc, positions, trades ->
            if (acc == null) return@combine null
            val openValue = positions.sumOf { it.quantity * it.entryPrice }
            val totalPnl = trades.sumOf { it.pnl }
            val wins = trades.count { it.pnl > 0 }
            val total = trades.size
            val winRate = if (total > 0) wins.toDouble() / total * 100 else 0.0
            // Simple drawdown from closed trades
            var peak = acc.initialBalance
            var equity = acc.initialBalance
            var maxDd = 0.0
            trades.sortedBy { it.closedAt }.forEach {
                equity += it.pnl
                if (equity > peak) peak = equity
                val dd = if (peak > 0) (peak - equity) / peak * 100 else 0.0
                if (dd > maxDd) maxDd = dd
            }
            PaperAccount(
                balance = acc.balance,
                equity = acc.balance + openValue, // simplified
                availableMargin = acc.balance,
                openPositionsValue = openValue,
                totalPnl = totalPnl,
                todayPnl = trades.filter {
                    it.closedAt > System.currentTimeMillis() - 86_400_000
                }.sumOf { it.pnl },
                winRate = winRate,
                totalTrades = total,
                maxDrawdown = maxDd
            )
        }
    }

    fun observePositions(): Flow<List<PaperPosition>> {
        return db.paperPositionDao().getAll().map { list ->
            list.map {
                PaperPosition(
                    id = it.id,
                    symbol = it.symbol,
                    name = it.name,
                    side = SignalType.valueOf(it.side),
                    quantity = it.quantity,
                    entryPrice = it.entryPrice,
                    currentPrice = it.entryPrice, // updated externally
                    stopLoss = it.stopLoss,
                    target = it.target,
                    openedAt = it.openedAt,
                    unrealizedPnl = 0.0,
                    unrealizedPnlPercent = 0.0
                )
            }
        }
    }

    fun observeTrades(): Flow<List<PaperTrade>> {
        return db.paperTradeDao().getAll().map { list ->
            list.map {
                PaperTrade(
                    id = it.id,
                    symbol = it.symbol,
                    name = it.name,
                    side = SignalType.valueOf(it.side),
                    quantity = it.quantity,
                    entryPrice = it.entryPrice,
                    exitPrice = it.exitPrice,
                    stopLoss = it.stopLoss,
                    target = it.target,
                    openedAt = it.openedAt,
                    closedAt = it.closedAt,
                    pnl = it.pnl,
                    pnlPercent = if (it.entryPrice > 0) it.pnl / (it.entryPrice * it.quantity) * 100 else 0.0,
                    result = TradeResult.valueOf(it.result)
                )
            }
        }
    }

    suspend fun openPosition(
        symbol: String,
        name: String,
        side: SignalType,
        quantity: Int,
        entryPrice: Double,
        stopLoss: Double?,
        target: Double?
    ): Long {
        val acc = db.paperAccountDao().getAccountOnce() ?: return -1
        val cost = quantity * entryPrice
        if (cost > acc.balance) return -1
        db.paperAccountDao().update(acc.copy(balance = acc.balance - cost))
        return db.paperPositionDao().insert(
            PaperPositionEntity(
                symbol = symbol,
                name = name,
                side = side.name,
                quantity = quantity,
                entryPrice = entryPrice,
                stopLoss = stopLoss,
                target = target,
                openedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun closePosition(positionId: Long, exitPrice: Double): Boolean {
        val pos = db.paperPositionDao().getById(positionId) ?: return false
        val side = SignalType.valueOf(pos.side)
        val pnl = when (side) {
            SignalType.BUY -> (exitPrice - pos.entryPrice) * pos.quantity
            SignalType.SELL -> (pos.entryPrice - exitPrice) * pos.quantity
            else -> 0.0
        }
        val result = when {
            pnl > 0 -> TradeResult.WIN
            pnl < 0 -> TradeResult.LOSS
            else -> TradeResult.BREAKEVEN
        }
        db.paperTradeDao().insert(
            PaperTradeEntity(
                symbol = pos.symbol,
                name = pos.name,
                side = pos.side,
                quantity = pos.quantity,
                entryPrice = pos.entryPrice,
                exitPrice = exitPrice,
                stopLoss = pos.stopLoss,
                target = pos.target,
                openedAt = pos.openedAt,
                closedAt = System.currentTimeMillis(),
                pnl = pnl,
                result = result.name
            )
        )
        val acc = db.paperAccountDao().getAccountOnce() ?: return false
        val proceeds = pos.quantity * exitPrice
        // For long: we already deducted entry cost; add exit proceeds
        // For short simplified same way for demo
        db.paperAccountDao().update(acc.copy(balance = acc.balance + proceeds))
        db.paperPositionDao().delete(positionId)
        return true
    }

    suspend fun resetAccount() {
        db.paperPositionDao().getAllOnce().forEach { db.paperPositionDao().delete(it.id) }
        // Keep trade history for stats, or clear if desired
        db.paperAccountDao().insert(PaperAccountEntity())
    }
}
