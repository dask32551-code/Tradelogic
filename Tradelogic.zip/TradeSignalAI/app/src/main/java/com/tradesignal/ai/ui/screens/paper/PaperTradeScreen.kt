package com.tradesignal.ai.ui.screens.paper

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tradesignal.ai.TradeSignalApp
import com.tradesignal.ai.data.model.SignalType
import com.tradesignal.ai.ui.components.DemoBanner
import com.tradesignal.ai.ui.components.DisclaimerBanner
import com.tradesignal.ai.ui.components.SectionHeader
import com.tradesignal.ai.ui.components.formatInr
import com.tradesignal.ai.ui.components.formatPrice
import com.tradesignal.ai.ui.theme.BorderDark
import com.tradesignal.ai.ui.theme.BuyGreen
import com.tradesignal.ai.ui.theme.CardDark
import com.tradesignal.ai.ui.theme.LossRed
import com.tradesignal.ai.ui.theme.ProfitGreen
import com.tradesignal.ai.ui.theme.SellRed
import com.tradesignal.ai.ui.theme.TextPrimary
import com.tradesignal.ai.ui.theme.TextSecondary
import kotlinx.coroutines.launch

@Composable
fun PaperTradeScreen() {
    val app = TradeSignalApp.instance
    val account by app.paperTradingRepository.observeAccount().collectAsState(initial = null)
    val positions by app.paperTradingRepository.observePositions().collectAsState(initial = emptyList())
    val trades by app.paperTradingRepository.observeTrades().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()

    var symbol by remember { mutableStateOf("NIFTY") }
    var qty by remember { mutableStateOf("50") }
    var price by remember { mutableStateOf("24500") }
    var message by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize()) {
        DemoBanner()
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    "Paper Trading",
                    color = TextPrimary,
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Virtual money only · No real capital at risk",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            item {
                val bal = account?.balance ?: 1_000_000.0
                val pnl = account?.totalPnl ?: 0.0
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardDark), border = androidx.compose.foundation.BorderStroke(1.dp, com.tradesignal.ai.ui.theme.BorderDark),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Virtual Balance", color = TextSecondary, style = MaterialTheme.typography.labelMedium)
                        Text(formatInr(bal), color = TextPrimary, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("Total P&L", color = TextSecondary, style = MaterialTheme.typography.labelSmall)
                                Text(
                                    formatInr(pnl),
                                    color = if (pnl >= 0) ProfitGreen else LossRed,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Column {
                                Text("Win Rate", color = TextSecondary, style = MaterialTheme.typography.labelSmall)
                                Text(
                                    "${"%.1f".format(account?.winRate ?: 0.0)}%",
                                    color = TextPrimary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Column {
                                Text("Trades", color = TextSecondary, style = MaterialTheme.typography.labelSmall)
                                Text(
                                    "${account?.totalTrades ?: 0}",
                                    color = TextPrimary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }

            item { SectionHeader("Place Order") }
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardDark), border = androidx.compose.foundation.BorderStroke(1.dp, com.tradesignal.ai.ui.theme.BorderDark),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = symbol,
                            onValueChange = { symbol = it.uppercase() },
                            label = { Text("Symbol") },
                            singleLine = true,
                            colors = fieldColors(),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = qty,
                                onValueChange = { qty = it.filter { c -> c.isDigit() } },
                                label = { Text("Qty") },
                                singleLine = true,
                                colors = fieldColors(),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = price,
                                onValueChange = { price = it.filter { c -> c.isDigit() || c == '.' } },
                                label = { Text("Price") },
                                singleLine = true,
                                colors = fieldColors(),
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = {
                                    scope.launch {
                                        val q = qty.toIntOrNull() ?: return@launch
                                        val p = price.toDoubleOrNull() ?: return@launch
                                        val id = app.paperTradingEngine.buy(symbol, symbol, q, p, null, null)
                                        message = if (id > 0) "BUY $q $symbol @ $p opened" else "Insufficient virtual balance"
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = BuyGreen),
                                modifier = Modifier.weight(1f)
                            ) { Text("BUY", color = TextPrimary) }
                            Button(
                                onClick = {
                                    scope.launch {
                                        val q = qty.toIntOrNull() ?: return@launch
                                        val p = price.toDoubleOrNull() ?: return@launch
                                        val id = app.paperTradingEngine.sell(symbol, symbol, q, p, null, null)
                                        message = if (id > 0) "SELL $q $symbol @ $p opened" else "Insufficient virtual balance"
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = SellRed),
                                modifier = Modifier.weight(1f)
                            ) { Text("SELL", color = TextPrimary) }
                        }
                        message?.let {
                            Text(it, color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }

            item { SectionHeader("Open Positions") }
            if (positions.isEmpty()) {
                item { Text("No open positions", color = TextSecondary) }
            }
            items(positions) { pos ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardDark), border = androidx.compose.foundation.BorderStroke(1.dp, com.tradesignal.ai.ui.theme.BorderDark),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${pos.side.displayName()} ${pos.symbol}", color = TextPrimary, fontWeight = FontWeight.SemiBold)
                            Text("Qty ${pos.quantity}", color = TextSecondary)
                        }
                        Text("Entry ${formatPrice(pos.entryPrice)}", color = TextSecondary)
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = {
                                scope.launch {
                                    // Close at same price for demo simplicity (user can change later)
                                    app.paperTradingEngine.close(pos.id, pos.entryPrice)
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = TextSecondary.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Close at entry (demo)", color = TextPrimary) }
                    }
                }
            }

            item { SectionHeader("Closed Trades") }
            items(trades.take(20)) { t ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardDark), border = androidx.compose.foundation.BorderStroke(1.dp, com.tradesignal.ai.ui.theme.BorderDark),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("${t.side.displayName()} ${t.symbol}", color = TextPrimary, fontWeight = FontWeight.SemiBold)
                            Text("${t.quantity} @ ${formatPrice(t.entryPrice)} → ${formatPrice(t.exitPrice)}", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                        }
                        Text(
                            formatInr(t.pnl),
                            color = if (t.pnl >= 0) ProfitGreen else LossRed,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            item {
                DisclaimerBanner()
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = BuyGreen,
    unfocusedBorderColor = BorderDark,
    focusedLabelColor = BuyGreen,
    unfocusedLabelColor = TextSecondary,
    focusedTextColor = TextPrimary,
    unfocusedTextColor = TextPrimary,
    cursorColor = BuyGreen
)
