package com.tradesignal.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material.icons.outlined.ShowChart
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.tradesignal.ai.ui.screens.backtest.BacktestScreen
import com.tradesignal.ai.ui.screens.home.HomeScreen
import com.tradesignal.ai.ui.screens.markets.MarketsScreen
import com.tradesignal.ai.ui.screens.paper.PaperTradeScreen
import com.tradesignal.ai.ui.screens.performance.PerformanceScreen
import com.tradesignal.ai.ui.screens.profile.ProfileScreen
import com.tradesignal.ai.ui.screens.setups.SetupsScreen
import com.tradesignal.ai.ui.theme.BackgroundDark
import com.tradesignal.ai.ui.theme.AccentBlue
import com.tradesignal.ai.ui.theme.BorderDark
import com.tradesignal.ai.ui.theme.TextPrimary
import com.tradesignal.ai.ui.theme.TextSecondary
import com.tradesignal.ai.ui.theme.TradeSignalTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TradeSignalTheme {
                TradeSignalAppNav()
            }
        }
    }
}

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    data object Home : Screen("home", "Home", Icons.Outlined.Home)
    data object Markets : Screen("markets", "Markets", Icons.Outlined.ShowChart)
    data object Setups : Screen("setups", "Setups", Icons.Outlined.BarChart)
    data object Paper : Screen("paper", "Paper", Icons.Outlined.Inventory2)
    data object Profile : Screen("profile", "More", Icons.Outlined.MoreHoriz)
}

val bottomScreens = listOf(
    Screen.Home,
    Screen.Markets,
    Screen.Setups,
    Screen.Paper,
    Screen.Profile
)

@Composable
fun TradeSignalAppNav() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = BackgroundDark,
        bottomBar = {
            Column {
                Box(Modifier.fillMaxWidth().height(1.dp).background(BorderDark))
                NavigationBar(
                    containerColor = Color.White,
                    contentColor = TextPrimary
                ) {
                    bottomScreens.forEach { screen ->
                        val selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true
                        NavigationBarItem(
                            icon = { Icon(screen.icon, contentDescription = screen.title) },
                            label = { Text(screen.title, maxLines = 1) },
                            selected = selected,
                            onClick = {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = AccentBlue,
                                selectedTextColor = AccentBlue,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary,
                                indicatorColor = Color.Transparent
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) {
                HomeScreen(
                    onNavigateToSetups = { navController.navigate(Screen.Setups.route) },
                    onNavigateToPaper = { navController.navigate(Screen.Paper.route) },
                    onNavigateToBacktest = { navController.navigate("backtest") },
                    onNavigateToPerformance = { navController.navigate("performance") }
                )
            }
            composable(Screen.Markets.route) {
                MarketsScreen()
            }
            composable(Screen.Setups.route) {
                SetupsScreen()
            }
            composable(Screen.Paper.route) {
                PaperTradeScreen()
            }
            composable(Screen.Profile.route) {
                ProfileScreen(
                    onNavigateToBacktest = { navController.navigate("backtest") },
                    onNavigateToPerformance = { navController.navigate("performance") }
                )
            }
            composable("backtest") {
                BacktestScreen(onBack = { navController.popBackStack() })
            }
            composable("performance") {
                PerformanceScreen(onBack = { navController.popBackStack() })
            }
        }
    }
}
