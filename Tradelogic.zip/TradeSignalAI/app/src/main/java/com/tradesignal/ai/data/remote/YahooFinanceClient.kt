package com.tradesignal.ai.data.remote

import com.google.gson.JsonArray
import com.google.gson.JsonParser
import com.tradesignal.ai.data.model.Ohlcv
import com.tradesignal.ai.data.model.Timeframe
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Maps the app's NSE/BSE symbols to Yahoo Finance tickers.
 * Indices have special tickers; every other symbol is an NSE stock (".NS").
 */
object YahooSymbols {
    private val special = mapOf(
        "NIFTY" to "^NSEI",
        "BANKNIFTY" to "^NSEBANK",
        "SENSEX" to "^BSESN"
    )

    fun toYahoo(symbol: String): String {
        val s = symbol.trim().uppercase()
        return special[s] ?: "$s.NS"
    }
}

/**
 * Free Yahoo Finance chart endpoint (no API key). Data is DELAYED (~15 min for NSE)
 * and the endpoint is unofficial, so every call must be treated as best-effort.
 * All methods are blocking: call from Dispatchers.IO.
 */
class YahooFinanceClient {

    data class Spec(val interval: String, val range: String)

    fun specFor(tf: Timeframe): Spec = when (tf) {
        Timeframe.M1 -> Spec("1m", "5d")
        Timeframe.M5 -> Spec("5m", "1mo")
        Timeframe.M15 -> Spec("15m", "1mo")
        Timeframe.H1 -> Spec("60m", "6mo")
        Timeframe.D1 -> Spec("1d", "1y")
    }

    @Throws(IOException::class)
    fun fetchCandles(symbol: String, tf: Timeframe): List<Ohlcv> {
        val spec = specFor(tf)
        val ticker = URLEncoder.encode(YahooSymbols.toYahoo(symbol), "UTF-8")
        var lastError: IOException? = null
        for (host in HOSTS) {
            val url = "https://$host/v8/finance/chart/$ticker" +
                "?interval=${spec.interval}&range=${spec.range}&includePrePost=false"
            try {
                return parseChart(httpGet(url))
            } catch (e: IOException) {
                lastError = e
            }
        }
        throw lastError ?: IOException("Yahoo request failed")
    }

    private fun httpGet(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "GET"
            conn.connectTimeout = 6_000
            conn.readTimeout = 8_000
            // Yahoo rejects requests without a browser-like User-Agent
            conn.setRequestProperty("User-Agent", USER_AGENT)
            conn.setRequestProperty("Accept", "application/json")
            val code = conn.responseCode
            if (code !in 200..299) throw IOException("Yahoo HTTP $code")
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    companion object {
        private val HOSTS = listOf("query1.finance.yahoo.com", "query2.finance.yahoo.com")
        private const val USER_AGENT =
            "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"

        /** Parses a Yahoo v8 chart response. Rows with null OHLC values are skipped. */
        @Throws(IOException::class)
        fun parseChart(json: String): List<Ohlcv> {
            val root = try {
                JsonParser.parseString(json).asJsonObject
            } catch (e: Exception) {
                throw IOException("Invalid Yahoo response", e)
            }
            val chart = root.getAsJsonObject("chart") ?: throw IOException("Missing chart")

            val err = chart.get("error")
            if (err != null && !err.isJsonNull) {
                val desc = err.asJsonObject.get("description")
                throw IOException("Yahoo error: " + (if (desc != null && !desc.isJsonNull) desc.asString else "unknown"))
            }

            val results = chart.getAsJsonArray("result")
            if (results == null || results.size() == 0) throw IOException("No data")
            val result = results.get(0).asJsonObject

            val timestamps = result.getAsJsonArray("timestamp") ?: return emptyList()
            val quotes = result.getAsJsonObject("indicators")?.getAsJsonArray("quote")
            if (quotes == null || quotes.size() == 0) return emptyList()
            val q = quotes.get(0).asJsonObject

            val open = q.getAsJsonArray("open")
            val high = q.getAsJsonArray("high")
            val low = q.getAsJsonArray("low")
            val close = q.getAsJsonArray("close")
            val volume = q.getAsJsonArray("volume")
            if (open == null || high == null || low == null || close == null) return emptyList()

            val out = ArrayList<Ohlcv>(timestamps.size())
            for (i in 0 until timestamps.size()) {
                val ts = timestamps.get(i)
                if (ts.isJsonNull) continue
                val o = open.doubleAt(i)
                val h = high.doubleAt(i)
                val l = low.doubleAt(i)
                val c = close.doubleAt(i)
                if (o == null || h == null || l == null || c == null) continue
                val v = volume?.doubleAt(i) ?: 0.0
                // Yahoo timestamps are in seconds; the app uses milliseconds
                out.add(Ohlcv(ts.asLong * 1000L, o, h, l, c, v))
            }
            return out
        }

        private fun JsonArray.doubleAt(i: Int): Double? {
            if (i >= size()) return null
            val e = get(i)
            return if (e.isJsonNull) null else e.asDouble
        }
    }
}
