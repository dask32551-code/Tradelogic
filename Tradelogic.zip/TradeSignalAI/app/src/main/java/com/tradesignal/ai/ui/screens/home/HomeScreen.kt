package com.tradesignal.ai.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tradesignal.ai.TradeSignalApp
import com.tradesignal.ai.data.model.MarketQuote
import com.tradesignal.ai.data.model.Timeframe
import com.tradesignal.ai.data.model.TradeSetup
import com.tradesignal.ai.ui.components.AppCard
import com.tradesignal.ai.ui.components.AppHeader
import com.tradesignal.ai.ui.components.DemoBanner
import com.tradesignal.ai.ui.components.DisclaimerBanner
import com.tradesignal.ai.ui.components.MonoFont
import com.tradesignal.ai.ui.components.QuoteCard
import com.tradesignal.ai.ui.components.SectionHeader
import com.tradesignal.ai.ui.components.SetupCard
import com.tradesignal.ai.ui.components.SignalBadge
import com.tradesignal.ai.ui.components.Sparkline
import com.tradesignal.ai.ui.components.StatCard
import com.tradesignal.ai.ui.components.formatInr
import com.tradesignal.ai.ui.components.formatPercent
import com.tradesignal.ai.ui.components.formatPrice
import com.tradesignal.ai.ui.theme.AccentBlue
import com.tradesignal.ai.ui.theme.BorderDark
import com.tradesignal.ai.ui.theme.LossRed
import com.tradesignal.ai.ui.theme.ProfitGreen
import com.tradesignal.ai.ui.theme.TextPrimary
import com.tradesignal.ai.ui.theme.TextSecondary
import com.tradesignal.ai.ui.theme.TextTertiary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val INDEX_SYMBOLS = listOf("NIFTY", "BANKNIFTY", "SENSEX")

@Composable
fun HomeScreen(
    onNavigateToSetups: () -> Unit,
    onNavigateToPaper: () -> Unit,
    onNavigateToBacktest: () -> Unit,
    onNavigateToPerformance: () -> Unit
) {
    val app = TradeSignalApp.instance
    var quotes by remember { mutableStateOf<List<MarketQuote>>(emptyList()) }
    var setups by remember { mutableStateOf<List<TradeSetup>>(emptyList()) }
    var sparks by remember { mutableStateOf<Map<String, List<Double>>>(emptyMap()) }
    var loading by remember { mutableStateOf(true) }
    var query by remember { mutableStateOf("") }
    val account by app.paperTradingRepository.observeAccount().collectAsState(initial = null)

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            val q = app.marketDataRepository.getQuotes()
            quotes = q

            val sparkMap = mutableMapOf<String, List<Double>>()
            for (idx in q.filter { it.symbol in INDEX_SYMBOLS }) {
                val candles = app.marketDataRepository.getCandles(idx.symbol, Timeframe.D1)
                sparkMap[idx.symbol] = candles.takeLast(40).map { it.close }
            }
            sparks = sparkMap

            val generated = mutableListOf<TradeSetup>()
            for (item in q.take(6)) {
                val candles = app.marketDataRepository.getCandles(item.symbol, Timeframe.D1)
                val s = app.signalRepository.generateAndSave(item.symbol, item.name, candles, Timeframe.D1)
                if (s != null) generated.add(s)
            }
            setups = generated.sortedByDescending { it.setupScore }.take(5)
            loading = false
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        AppHeader()
        if (loading) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CircularProgressIndicator(color = AccentBlue)
                Spacer(Modifier.height(12.dp))
                Text("Loading demo market data…", color = TextSecondary)
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Column {
                        Spacer(Modifier.height(12.dp))
                        DemoBannerInline()
                        Spacer(Modifier.height(8.dp))
                        SearchField(query) { query = it }
                    }
                }

                if (query.isNotBlank()) {
                    val results = quotes.filter {
                        it.symbol.contains(query, ignoreCase = true) ||
                            it.name.contains(query, ignoreCase = true)
                    }
                    if (results.isEmpty()) {
                        item {
                            Text(
                                "No matches for \"$query\"",
                                color = TextSecondary,
                                modifier = Modifier.padding(vertical = 16.dp)
                            )
                        }
                    }
                    items(results) { QuoteCard(it) }
                } else {
                    item { SectionHeader("Indices") }
                    item {
                        IndicesCard(
                            indices = quotes.filter { it.symbol in INDEX_SYMBOLS },
                            sparks = sparks
                        )
                    }

                    item { SectionHeader("Paper Account", "Open", onNavigateToPaper) }
                    item {
                        val pnl = account?.totalPnl ?: 0.0
                        val today = account?.todayPnl ?: 0.0
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            StatCard(
                                title = "Overall P&L",
                                value = formatInr(pnl),
                                valueColor = if (pnl >= 0) ProfitGreen else LossRed,
                                modifier = Modifier.weight(1f)
                            )
                            StatCard(
                                title = "Today P&L",
                                value = formatInr(today),
                                valueColor = if (today >= 0) ProfitGreen else LossRed,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    item { SectionHeader("Top Setups", "See all", onNavigateToSetups) }
                    items(setups) { SetupCard(it) }

                    item { SectionHeader("Popular Stocks") }
                    items(quotes.filter { it.symbol !in INDEX_SYMBOLS }.take(6)) { QuoteCard(it) }

                    item { SectionHeader("Tools") }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            ToolTile("Backtest", onNavigateToBacktest, Modifier.weight(1f))
                            ToolTile("Performance", onNavigateToPerformance, Modifier.weight(1f))
                        }
                    }

                    item {
                        Spacer(Modifier.height(8.dp))
                        DisclaimerBanner()
                    }
                }
            }
        }
    }
}

@Composable
private fun DemoBannerInline() {
    // Same note as DemoBanner() but without the extra horizontal padding (list already pads 16dp)
    Box(Modifier.padding(vertical = 4.dp)) {
        com.tradesignal.ai.ui.components.NoteQuote(
            com.tradesignal.ai.ui.components.dataNoteText()
        )
    }
}

@Composable
private fun SearchField(value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        shape = RoundedCornerShape(12.dp),
        placeholder = { Text("Search stocks, gold, crypto", fontSize = 17.sp) },
        leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = Color.White,
            unfocusedContainerColor = Color.White,
            focusedBorderColor = AccentBlue,
            unfocusedBorderColor = BorderDark,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary,
            focusedPlaceholderColor = TextTertiary,
            unfocusedPlaceholderColor = TextTertiary,
            focusedLeadingIconColor = TextSecondary,
            unfocusedLeadingIconColor = TextSecondary,
            cursorColor = AccentBlue
        )
    )
}

@Composable
private fun IndicesCard(indices: List<MarketQuote>, sparks: Map<String, List<Double>>) {
    AppCard(modifier = Modifier.fillMaxWidth()) {
        indices.forEachIndexed { i, q ->
            if (i > 0) Box(Modifier.fillMaxWidth().height(1.dp).background(BorderDark))
            IndexRow(q, sparks[q.symbol].orEmpty())
        }
    }
}

@Composable
private fun IndexRow(quote: MarketQuote, spark: List<Double>) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                quote.symbol,
                color = TextPrimary,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
            Text(quote.name, color = TextSecondary, fontSize = 14.sp, maxLines = 1)
        }
        Sparkline(spark, Modifier.width(58.dp).height(28.dp))
        Spacer(Modifier.width(12.dp))
        Column(horizontalAlignment = Alignment.End) {
            Text(
                formatPrice(quote.price),
                color = TextPrimary,
                fontFamily = MonoFont,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium
            )
            Text(
                formatPercent(quote.changePercent),
                color = if (quote.changePercent >= 0) ProfitGreen else LossRed,
                fontFamily = MonoFont,
                fontSize = 13.sp
            )
        }
        Spacer(Modifier.width(10.dp))
        SignalBadge(quote.signal)
    }
}

@Composable
private fun ToolTile(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    AppCard(modifier = modifier, onClick = onClick) {
        Text(
            text = text,
            color = AccentBlue,
            fontWeight = FontWeight.SemiBold,
            fontSize = 16.sp,
            modifier = Modifier.padding(16.dp)
        )
    }
}
