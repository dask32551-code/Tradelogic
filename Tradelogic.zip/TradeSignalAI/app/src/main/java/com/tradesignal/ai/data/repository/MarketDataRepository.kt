package com.tradesignal.ai.data.repository

import android.content.Context
import android.util.Log
import androidx.room.withTransaction
import com.tradesignal.ai.data.local.AppDatabase
import com.tradesignal.ai.data.local.OhlcvEntity
import com.tradesignal.ai.data.model.Instrument
import com.tradesignal.ai.data.model.InstrumentType
import com.tradesignal.ai.data.model.MarketQuote
import com.tradesignal.ai.data.model.Ohlcv
import com.tradesignal.ai.data.model.SignalType
import com.tradesignal.ai.data.model.Timeframe
import com.tradesignal.ai.data.model.Trend
import com.tradesignal.ai.data.remote.YahooFinanceClient
import com.tradesignal.ai.domain.engine.StrategyEngine
import com.tradesignal.ai.domain.indicators.IndicatorCalculator
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.sin
import kotlin.random.Random

/**
 * Market data layer.
 *
 * Source: Yahoo Finance (free, no API key). Prices are DELAYED (~15 min for NSE).
 * Candles are cached in Room and refreshed only when older than a per-timeframe TTL.
 * If a fetch fails (offline, rate limit, bad symbol) the app keeps serving whatever is
 * cached, falling back to locally generated DEMO candles that are labelled as demo.
 */
class MarketDataRepository(
    private val context: Context,
    private val db: AppDatabase
) {
    private val calculator = IndicatorCalculator()
    private val engine = StrategyEngine(calculator)
    private val yahoo = YahooFinanceClient()
    private val prefs = context.getSharedPreferences("market_data", Context.MODE_PRIVATE)
    private val locks = ConcurrentHashMap<String, Mutex>()
    private val lastFailure = ConcurrentHashMap<String, Long>()

    /** Where the data currently on screen comes from. */
    enum class DataStatus { DEMO, MIXED, DELAYED }

    val popularInstruments = listOf(
        Instrument("NIFTY", "Nifty 50", InstrumentType.INDEX),
        Instrument("BANKNIFTY", "Bank Nifty", InstrumentType.INDEX),
        Instrument("SENSEX", "Sensex", InstrumentType.INDEX),
        Instrument("RELIANCE", "Reliance Industries", InstrumentType.STOCK),
        Instrument("TCS", "Tata Consultancy Services", InstrumentType.STOCK),
        Instrument("HDFCBANK", "HDFC Bank", InstrumentType.STOCK),
        Instrument("INFY", "Infosys", InstrumentType.STOCK),
        Instrument("ICICIBANK", "ICICI Bank", InstrumentType.STOCK),
        Instrument("SBIN", "State Bank of India", InstrumentType.STOCK),
        Instrument("BHARTIARTL", "Bharti Airtel", InstrumentType.STOCK),
        Instrument("ITC", "ITC Limited", InstrumentType.STOCK),
        Instrument("LT", "Larsen & Toubro", InstrumentType.STOCK)
    )

    private val _status = MutableStateFlow(computeStatus())
    val status: StateFlow<DataStatus> = _status.asStateFlow()

    /** True once real (delayed) daily data for this symbol has been fetched and cached. */
    fun isLive(symbol: String): Boolean = prefs.getLong(liveKey(symbol, Timeframe.D1), 0L) > 0L

    private fun liveKey(symbol: String, tf: Timeframe) = "live_${symbol}_${tf.name}"

    private fun computeStatus(): DataStatus {
        val live = popularInstruments.count { isLive(it.symbol) }
        return when {
            live == 0 -> DataStatus.DEMO
            live == popularInstruments.size -> DataStatus.DELAYED
            else -> DataStatus.MIXED
        }
    }

    private fun ttlMs(tf: Timeframe): Long = when (tf) {
        Timeframe.M1 -> 60_000L
        Timeframe.M5 -> 2 * 60_000L
        Timeframe.M15 -> 5 * 60_000L
        Timeframe.H1 -> 10 * 60_000L
        Timeframe.D1 -> 15 * 60_000L
    }

    /**
     * Fetches fresh candles from Yahoo if the cached copy is older than the TTL.
     * Never throws (except cancellation): on failure the existing cache stays untouched
     * and the call is not retried for [RETRY_BACKOFF_MS].
     */
    private suspend fun refreshIfStale(symbol: String, tf: Timeframe) {
        val key = "${symbol}_${tf.name}"
        locks.getOrPut(key) { Mutex() }.withLock {
            val now = System.currentTimeMillis()
            val lastOk = prefs.getLong("live_$key", 0L)
            if (lastOk > 0L && now - lastOk < ttlMs(tf)) return
            if (now - (lastFailure[key] ?: 0L) < RETRY_BACKOFF_MS) return

            try {
                val candles = withContext(Dispatchers.IO) { yahoo.fetchCandles(symbol, tf) }
                if (candles.size < MIN_CANDLES) {
                    lastFailure[key] = now
                    return
                }
                val entities = candles.map {
                    OhlcvEntity(
                        symbol = symbol,
                        timeframe = tf.name,
                        timestamp = it.timestamp,
                        open = it.open,
                        high = it.high,
                        low = it.low,
                        close = it.close,
                        volume = it.volume
                    )
                }
                db.withTransaction {
                    db.ohlcvDao().deleteForSymbol(symbol, tf.name)
                    db.ohlcvDao().insertAll(entities)
                }
                prefs.edit().putLong("live_$key", now).apply()
                _status.value = computeStatus()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                lastFailure[key] = now
                Log.w("MarketData", "Yahoo fetch failed for $key: ${e.message}")
            }
        }
    }

    suspend fun ensureDemoData() = withContext(Dispatchers.IO) {
        val count = db.ohlcvDao().countForSymbol("NIFTY")
        if (count > 100) return@withContext

        for (inst in popularInstruments) {
            for (tf in listOf(Timeframe.M15, Timeframe.H1, Timeframe.D1)) {
                val candles = generateDemoCandles(inst.symbol, tf, 300)
                val entities = candles.map {
                    OhlcvEntity(
                        symbol = inst.symbol,
                        timeframe = tf.name,
                        timestamp = it.timestamp,
                        open = it.open,
                        high = it.high,
                        low = it.low,
                        close = it.close,
                        volume = it.volume
                    )
                }
                db.ohlcvDao().insertAll(entities)
            }
        }
    }

    suspend fun getCandles(symbol: String, timeframe: Timeframe): List<Ohlcv> =
        withContext(Dispatchers.IO) {
            refreshIfStale(symbol, timeframe)
            db.ohlcvDao().getCandles(symbol, timeframe.name).map {
                Ohlcv(it.timestamp, it.open, it.high, it.low, it.close, it.volume)
            }
        }

    suspend fun getCandlesInRange(
        symbol: String,
        timeframe: Timeframe,
        start: Long,
        end: Long
    ): List<Ohlcv> = withContext(Dispatchers.IO) {
        refreshIfStale(symbol, timeframe)
        db.ohlcvDao().getCandlesInRange(symbol, timeframe.name, start, end).map {
            Ohlcv(it.timestamp, it.open, it.high, it.low, it.close, it.volume)
        }
    }

    suspend fun getQuotes(): List<MarketQuote> = withContext(Dispatchers.IO) {
        // Refresh all symbols in parallel (cached by TTL, so this is cheap when fresh)
        coroutineScope {
            popularInstruments.map { inst ->
                async { refreshIfStale(inst.symbol, Timeframe.D1) }
            }.awaitAll()
        }
        popularInstruments.map { inst ->
            val candles = getCandles(inst.symbol, Timeframe.D1)
            if (candles.isEmpty()) {
                MarketQuote(
                    symbol = inst.symbol,
                    name = inst.name,
                    price = 0.0,
                    change = 0.0,
                    changePercent = 0.0,
                    trend = Trend.SIDEWAYS,
                    signal = SignalType.NONE,
                    signalStrength = 0,
                    isDemo = !isLive(inst.symbol)
                )
            } else {
                val last = candles.last()
                val prev = candles.getOrNull(candles.size - 2)?.close ?: last.close
                val change = last.close - prev
                val changePct = if (prev != 0.0) (change / prev) * 100 else 0.0
                val setup = engine.analyze(inst.symbol, inst.name, candles, Timeframe.D1)
                val trend = when {
                    changePct > 0.3 -> Trend.BULLISH
                    changePct < -0.3 -> Trend.BEARISH
                    else -> Trend.SIDEWAYS
                }
                MarketQuote(
                    symbol = inst.symbol,
                    name = inst.name,
                    price = last.close,
                    change = change,
                    changePercent = changePct,
                    trend = trend,
                    signal = setup?.signal ?: SignalType.NONE,
                    signalStrength = setup?.setupScore ?: 50,
                    high = last.high,
                    low = last.low,
                    volume = last.volume,
                    isDemo = !isLive(inst.symbol)
                )
            }
        }
    }

    suspend fun importCsv(symbol: String, timeframe: Timeframe, csvContent: String): Int =
        withContext(Dispatchers.IO) {
            // Simple CSV: timestamp,open,high,low,close,volume
            val lines = csvContent.lines().filter { it.isNotBlank() && !it.startsWith("#") }
            val entities = mutableListOf<OhlcvEntity>()
            for (line in lines) {
                val parts = line.split(",").map { it.trim() }
                if (parts.size < 6) continue
                try {
                    entities.add(
                        OhlcvEntity(
                            symbol = symbol,
                            timeframe = timeframe.name,
                            timestamp = parts[0].toLong(),
                            open = parts[1].toDouble(),
                            high = parts[2].toDouble(),
                            low = parts[3].toDouble(),
                            close = parts[4].toDouble(),
                            volume = parts[5].toDouble()
                        )
                    )
                } catch (_: Exception) { /* skip bad lines */ }
            }
            if (entities.isNotEmpty()) {
                db.ohlcvDao().deleteForSymbol(symbol, timeframe.name)
                db.ohlcvDao().insertAll(entities)
            }
            entities.size
        }

    /**
     * Generates realistic-looking demo OHLCV using a random walk with mild trend.
     * Clearly marked as demo.
     */
    private fun generateDemoCandles(
        symbol: String,
        timeframe: Timeframe,
        count: Int
    ): List<Ohlcv> {
        val basePrice = when (symbol) {
            "NIFTY" -> 24500.0
            "BANKNIFTY" -> 52000.0
            "SENSEX" -> 80000.0
            "RELIANCE" -> 2950.0
            "TCS" -> 4100.0
            "HDFCBANK" -> 1680.0
            "INFY" -> 1850.0
            "ICICIBANK" -> 1250.0
            "SBIN" -> 820.0
            "BHARTIARTL" -> 1550.0
            "ITC" -> 470.0
            "LT" -> 3600.0
            else -> 1000.0
        }

        val intervalMs = timeframe.minutes * 60_000L
        val now = System.currentTimeMillis()
        val start = now - (count * intervalMs)
        val rng = Random(symbol.hashCode() + timeframe.ordinal)

        val candles = mutableListOf<Ohlcv>()
        var price = basePrice * (0.92 + rng.nextDouble() * 0.08)

        for (i in 0 until count) {
            val ts = start + i * intervalMs
            val drift = sin(i / 25.0) * 0.0015 + (rng.nextDouble() - 0.48) * 0.008
            val open = price
            val close = open * (1 + drift)
            val high = maxOf(open, close) * (1 + rng.nextDouble() * 0.004)
            val low = minOf(open, close) * (1 - rng.nextDouble() * 0.004)
            val vol = 100_000 + rng.nextDouble() * 500_000
            candles.add(Ohlcv(ts, open, high, low, close, vol))
            price = close
        }
        return candles
    }

    private companion object {
        const val RETRY_BACKOFF_MS = 60_000L
        const val MIN_CANDLES = 20
    }
}
