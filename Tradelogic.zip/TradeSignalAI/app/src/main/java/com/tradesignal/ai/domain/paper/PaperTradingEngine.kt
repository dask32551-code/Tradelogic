package com.tradesignal.ai.domain.paper

import com.tradesignal.ai.data.model.SignalType
import com.tradesignal.ai.data.repository.PaperTradingRepository

class PaperTradingEngine(
    private val repository: PaperTradingRepository
) {
    suspend fun buy(
        symbol: String,
        name: String,
        quantity: Int,
        price: Double,
        stopLoss: Double?,
        target: Double?
    ): Long {
        return repository.openPosition(
            symbol = symbol,
            name = name,
            side = SignalType.BUY,
            quantity = quantity,
            entryPrice = price,
            stopLoss = stopLoss,
            target = target
        )
    }

    suspend fun sell(
        symbol: String,
        name: String,
        quantity: Int,
        price: Double,
        stopLoss: Double?,
        target: Double?
    ): Long {
        return repository.openPosition(
            symbol = symbol,
            name = name,
            side = SignalType.SELL,
            quantity = quantity,
            entryPrice = price,
            stopLoss = stopLoss,
            target = target
        )
    }

    suspend fun close(positionId: Long, exitPrice: Double): Boolean {
        return repository.closePosition(positionId, exitPrice)
    }
}
