package com.tradesignal.ai.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.tradesignal.ai.data.model.AlertType
import com.tradesignal.ai.data.model.SignalType
import com.tradesignal.ai.data.model.TradeResult

@Entity(tableName = "ohlcv")
data class OhlcvEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val symbol: String,
    val timeframe: String,
    val timestamp: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double
)

@Entity(tableName = "signals")
data class SignalEntity(
    @PrimaryKey val id: String,
    val symbol: String,
    val name: String,
    val timeframe: String,
    val signal: String,
    val entry: Double,
    val stopLoss: Double,
    val target1: Double,
    val target2: Double,
    val riskReward: Double,
    val setupScore: Int,
    val strategyName: String,
    val timestamp: Long,
    val reason: String,
    val trend: String,
    val riskLevel: String,
    val result: String = TradeResult.OPEN.name,
    val exitPrice: Double? = null,
    val pnl: Double? = null,
    val closedAt: Long? = null
)

@Entity(tableName = "watchlist")
data class WatchlistEntity(
    @PrimaryKey val symbol: String,
    val name: String,
    val type: String,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "paper_account")
data class PaperAccountEntity(
    @PrimaryKey val id: Int = 1,
    val balance: Double = 1_000_000.0,
    val initialBalance: Double = 1_000_000.0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "paper_positions")
data class PaperPositionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val symbol: String,
    val name: String,
    val side: String,
    val quantity: Int,
    val entryPrice: Double,
    val stopLoss: Double?,
    val target: Double?,
    val openedAt: Long
)

@Entity(tableName = "paper_trades")
data class PaperTradeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val symbol: String,
    val name: String,
    val side: String,
    val quantity: Int,
    val entryPrice: Double,
    val exitPrice: Double,
    val stopLoss: Double?,
    val target: Double?,
    val openedAt: Long,
    val closedAt: Long,
    val pnl: Double,
    val result: String
)

@Entity(tableName = "alerts")
data class AlertEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val symbol: String,
    val type: String,
    val conditionValue: Double?,
    val enabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_settings")
data class UserSettingsEntity(
    @PrimaryKey val id: Int = 1,
    val preferredRiskReward: Double = 2.0,
    val riskPercent: Double = 1.0,
    val isPremium: Boolean = false,
    val defaultTimeframe: String = "M15"
)
