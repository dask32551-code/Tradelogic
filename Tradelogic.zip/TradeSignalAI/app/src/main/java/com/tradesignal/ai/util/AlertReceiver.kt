package com.tradesignal.ai.util

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Placeholder for future scheduled alert checks.
 * Notifications are posted from application code when conditions are met.
 */
class AlertReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        // Future: evaluate price / RSI / setup alerts and post notifications
    }
}
