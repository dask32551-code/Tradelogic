package com.tradesignal.ai.ui.screens.backtest

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tradesignal.ai.TradeSignalApp
import com.tradesignal.ai.data.model.BacktestConfig
import com.tradesignal.ai.data.model.BacktestResult
import com.tradesignal.ai.data.model.Timeframe
import com.tradesignal.ai.domain.backtest.BacktestEngine
import com.tradesignal.ai.ui.components.DemoBanner
import com.tradesignal.ai.ui.components.DisclaimerBanner
import com.tradesignal.ai.ui.theme.BuyGreen
import com.tradesignal.ai.ui.theme.CardDark
import com.tradesignal.ai.ui.theme.LossRed
import com.tradesignal.ai.ui.theme.ProfitGreen
import com.tradesignal.ai.ui.theme.TextPrimary
import com.tradesignal.ai.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun BacktestScreen(onBack: () -> Unit) {
    val app = TradeSignalApp.instance
    val scope = rememberCoroutineScope()
    var loading by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<BacktestResult?>(null) }
    var symbol by remember { mutableStateOf("NIFTY") }

    Column(Modifier.fillMaxSize()) {
        DemoBanner()
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
            }
            Text(
                "Backtesting",
                color = TextPrimary,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
        }

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    "Historical / Simulated performance only. Not a guarantee of future results.",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            item {
                Card(colors = CardDefaults.cardColors(containerColor = CardDark), border = androidx.compose.foundation.BorderStroke(1.dp, com.tradesignal.ai.ui.theme.BorderDark), shape = RoundedCornerShape(12.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Instrument: $symbol (demo data)", color = TextPrimary)
                        Text("Timeframe: Daily · Strategy: Multi-Indicator Confluence · R:R 1:2", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                        Button(
                            onClick = {
                                scope.launch {
                                    loading = true
                                    result = withContext(Dispatchers.Default) {
                                        val candles = app.marketDataRepository.getCandles(symbol, Timeframe.D1)
                                        val config = BacktestConfig(
                                            symbol = symbol,
                                            timeframe = Timeframe.D1,
                                            startDate = candles.firstOrNull()?.timestamp ?: 0L,
                                            endDate = candles.lastOrNull()?.timestamp ?: 0L,
                                            strategyName = "Multi-Indicator Confluence",
                                            riskReward = 2.0
                                        )
                                        BacktestEngine().run(config, candles)
                                    }
                                    loading = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = BuyGreen),
                            enabled = !loading,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            if (loading) CircularProgressIndicator(color = TextPrimary, modifier = Modifier.height(20.dp))
                            else Text("Run Backtest", color = TextPrimary)
                        }
                    }
                }
            }

            result?.let { r ->
                item {
                    Text("Simulated Results", color = TextPrimary, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                }
                item {
                    ResultGrid(r)
                }
                item {
                    DisclaimerBanner()
                }
            }
        }
    }
}

@Composable
private fun ResultGrid(r: BacktestResult) {
    Card(colors = CardDefaults.cardColors(containerColor = CardDark), border = androidx.compose.foundation.BorderStroke(1.dp, com.tradesignal.ai.ui.theme.BorderDark), shape = RoundedCornerShape(12.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            StatRow("Total Trades", "${r.totalTrades}")
            StatRow("Winning / Losing", "${r.winningTrades} / ${r.losingTrades}")
            StatRow("Win Rate", "${"%.1f".format(r.winRate)}%")
            StatRow("Profit Factor", "%.2f".format(r.profitFactor))
            StatRow("Max Drawdown", "${"%.1f".format(r.maxDrawdownPercent)}%")
            StatRow("Net Simulated P&L (pts)", "%.2f".format(r.netPnl), if (r.netPnl >= 0) ProfitGreen else LossRed)
            StatRow("Avg Win / Avg Loss", "${"%.2f".format(r.averageWin)} / ${"%.2f".format(r.averageLoss)}")
            StatRow("Max Consec. Wins / Losses", "${r.consecutiveWins} / ${r.consecutiveLosses}")
        }
    }
}

@Composable
private fun StatRow(label: String, value: String, valueColor: androidx.compose.ui.graphics.Color = TextPrimary) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
        Text(value, color = valueColor, fontWeight = FontWeight.SemiBold)
    }
}
