package com.tradesignal.ai.ui.screens.setups

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tradesignal.ai.TradeSignalApp
import com.tradesignal.ai.data.model.Timeframe
import com.tradesignal.ai.data.model.TradeSetup
import com.tradesignal.ai.ui.components.DemoBanner
import com.tradesignal.ai.ui.components.DisclaimerBanner
import com.tradesignal.ai.ui.components.SetupCard
import com.tradesignal.ai.ui.theme.BuyGreen
import com.tradesignal.ai.ui.theme.TextPrimary
import com.tradesignal.ai.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun SetupsScreen() {
    val app = TradeSignalApp.instance
    var setups by remember { mutableStateOf<List<TradeSetup>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            val quotes = app.marketDataRepository.getQuotes()
            val list = mutableListOf<TradeSetup>()
            for (q in quotes) {
                val candles = app.marketDataRepository.getCandles(q.symbol, Timeframe.D1)
                val s = app.signalRepository.generateAndSave(
                    q.symbol, q.name, candles, Timeframe.D1, 2.0
                )
                if (s != null) list.add(s)
            }
            setups = list.sortedByDescending { it.setupScore }
            loading = false
        }
    }

    Column(Modifier.fillMaxSize()) {
        DemoBanner()
        if (loading) {
            Column(
                Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CircularProgressIndicator(color = BuyGreen)
                Spacer(Modifier.height(8.dp))
                Text("Scanning for setups…", color = TextSecondary)
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(
                        "Top Setups",
                        color = TextPrimary,
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "Quality score reflects indicator confluence — not a profit probability.",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(Modifier.height(4.dp))
                }
                if (setups.isEmpty()) {
                    item {
                        Text(
                            "No high-confluence setups right now. Markets may be ranging.",
                            color = TextSecondary
                        )
                    }
                }
                items(setups) { setup ->
                    SetupCard(setup)
                }
                item {
                    DisclaimerBanner()
                    Spacer(Modifier.height(16.dp))
                }
            }
        }
    }
}
