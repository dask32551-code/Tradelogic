package com.tradesignal.ai.domain.indicators

import com.tradesignal.ai.data.model.IndicatorValues
import com.tradesignal.ai.data.model.Ohlcv
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Pure local technical indicator calculations.
 * No network. Works on any OHLCV series.
 */
class IndicatorCalculator {

    fun calculateAll(candles: List<Ohlcv>): IndicatorValues {
        if (candles.isEmpty()) return IndicatorValues()
        val closes = candles.map { it.close }
        val highs = candles.map { it.high }
        val lows = candles.map { it.low }
        val volumes = candles.map { it.volume }

        val ema9 = ema(closes, 9).lastOrNull()
        val ema20 = ema(closes, 20).lastOrNull()
        val ema50 = ema(closes, 50).lastOrNull()
        val ema200 = ema(closes, 200).lastOrNull()
        val rsi = rsi(closes, 14).lastOrNull()
        val (macdLine, signal, hist) = macd(closes)
        val vwap = vwap(candles).lastOrNull()
        val (bbUpper, bbMid, bbLower) = bollinger(closes, 20, 2.0)
        val atr = atr(highs, lows, closes, 14).lastOrNull()
        val volAvg = sma(volumes, 20).lastOrNull()
        val (support, resistance) = supportResistance(candles, lookback = 50)

        return IndicatorValues(
            ema9 = ema9,
            ema20 = ema20,
            ema50 = ema50,
            ema200 = ema200,
            rsi = rsi,
            macdLine = macdLine.lastOrNull(),
            macdSignal = signal.lastOrNull(),
            macdHistogram = hist.lastOrNull(),
            vwap = vwap,
            bbUpper = bbUpper.lastOrNull(),
            bbMiddle = bbMid.lastOrNull(),
            bbLower = bbLower.lastOrNull(),
            atr = atr,
            volumeAvg = volAvg,
            support = support,
            resistance = resistance
        )
    }

    fun ema(values: List<Double>, period: Int): List<Double> {
        if (values.isEmpty() || period <= 0) return emptyList()
        val result = mutableListOf<Double>()
        val multiplier = 2.0 / (period + 1)
        var prev = values.take(period).average()
        result.add(prev)
        for (i in period until values.size) {
            val current = (values[i] - prev) * multiplier + prev
            result.add(current)
            prev = current
        }
        // Pad beginning to match length
        val pad = List(period - 1) { values.first() }
        return pad + result
    }

    fun sma(values: List<Double>, period: Int): List<Double> {
        if (values.size < period) return emptyList()
        val result = mutableListOf<Double>()
        for (i in period - 1 until values.size) {
            result.add(values.subList(i - period + 1, i + 1).average())
        }
        return List(period - 1) { values.first() } + result
    }

    fun rsi(closes: List<Double>, period: Int = 14): List<Double> {
        if (closes.size < period + 1) return emptyList()
        val changes = closes.zipWithNext { a, b -> b - a }
        val gains = changes.map { max(it, 0.0) }
        val losses = changes.map { max(-it, 0.0) }

        var avgGain = gains.take(period).average()
        var avgLoss = losses.take(period).average()
        val result = mutableListOf<Double>()

        val rs0 = if (avgLoss == 0.0) 100.0 else avgGain / avgLoss
        result.add(100.0 - (100.0 / (1.0 + rs0)))

        for (i in period until changes.size) {
            avgGain = (avgGain * (period - 1) + gains[i]) / period
            avgLoss = (avgLoss * (period - 1) + losses[i]) / period
            val rs = if (avgLoss == 0.0) 100.0 else avgGain / avgLoss
            result.add(100.0 - (100.0 / (1.0 + rs)))
        }
        return List(period) { 50.0 } + result
    }

    fun macd(
        closes: List<Double>,
        fast: Int = 12,
        slow: Int = 26,
        signalPeriod: Int = 9
    ): Triple<List<Double>, List<Double>, List<Double>> {
        val emaFast = ema(closes, fast)
        val emaSlow = ema(closes, slow)
        val macdLine = emaFast.zip(emaSlow) { f, s -> f - s }
        val signalLine = ema(macdLine, signalPeriod)
        val histogram = macdLine.zip(signalLine) { m, s -> m - s }
        return Triple(macdLine, signalLine, histogram)
    }

    fun bollinger(
        closes: List<Double>,
        period: Int = 20,
        stdDevMult: Double = 2.0
    ): Triple<List<Double>, List<Double>, List<Double>> {
        if (closes.size < period) {
            return Triple(emptyList(), emptyList(), emptyList())
        }
        val middle = sma(closes, period)
        val upper = mutableListOf<Double>()
        val lower = mutableListOf<Double>()
        for (i in period - 1 until closes.size) {
            val slice = closes.subList(i - period + 1, i + 1)
            val mean = slice.average()
            val variance = slice.map { (it - mean) * (it - mean) }.average()
            val std = sqrt(variance)
            upper.add(mean + stdDevMult * std)
            lower.add(mean - stdDevMult * std)
        }
        val pad = List(period - 1) { closes.first() }
        return Triple(pad + upper, middle, pad + lower)
    }

    fun atr(
        highs: List<Double>,
        lows: List<Double>,
        closes: List<Double>,
        period: Int = 14
    ): List<Double> {
        if (highs.size < 2) return emptyList()
        val tr = mutableListOf<Double>()
        tr.add(highs[0] - lows[0])
        for (i in 1 until highs.size) {
            val hl = highs[i] - lows[i]
            val hc = abs(highs[i] - closes[i - 1])
            val lc = abs(lows[i] - closes[i - 1])
            tr.add(max(hl, max(hc, lc)))
        }
        return sma(tr, period)
    }

    fun vwap(candles: List<Ohlcv>): List<Double> {
        if (candles.isEmpty()) return emptyList()
        val result = mutableListOf<Double>()
        var cumVol = 0.0
        var cumTPV = 0.0
        for (c in candles) {
            val tp = (c.high + c.low + c.close) / 3.0
            cumVol += c.volume
            cumTPV += tp * c.volume
            result.add(if (cumVol > 0) cumTPV / cumVol else c.close)
        }
        return result
    }

    fun supportResistance(
        candles: List<Ohlcv>,
        lookback: Int = 50
    ): Pair<Double?, Double?> {
        if (candles.isEmpty()) return null to null
        val window = candles.takeLast(min(lookback, candles.size))
        val support = window.minOfOrNull { it.low }
        val resistance = window.maxOfOrNull { it.high }
        return support to resistance
    }

    /** Swing low for stop loss placement */
    fun recentSwingLow(candles: List<Ohlcv>, lookback: Int = 10): Double? {
        if (candles.size < lookback) return candles.minOfOrNull { it.low }
        return candles.takeLast(lookback).minOfOrNull { it.low }
    }

    fun recentSwingHigh(candles: List<Ohlcv>, lookback: Int = 10): Double? {
        if (candles.size < lookback) return candles.maxOfOrNull { it.high }
        return candles.takeLast(lookback).maxOfOrNull { it.high }
    }
}
