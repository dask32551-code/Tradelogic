package com.tradesignal.ai.data.repository

import com.tradesignal.ai.data.local.AppDatabase
import com.tradesignal.ai.data.local.SignalEntity
import com.tradesignal.ai.data.model.SignalType
import com.tradesignal.ai.data.model.Timeframe
import com.tradesignal.ai.data.model.TradeResult
import com.tradesignal.ai.data.model.TradeSetup
import com.tradesignal.ai.domain.engine.StrategyEngine
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class SignalRepository(
    private val db: AppDatabase,
    private val engine: StrategyEngine
) {
    fun getRecentSignals(limit: Int = 30): Flow<List<TradeSetup>> {
        return db.signalDao().getRecentSignals(limit).map { list ->
            list.map { it.toSetup() }
        }
    }

    suspend fun generateAndSave(
        symbol: String,
        name: String,
        candles: List<com.tradesignal.ai.data.model.Ohlcv>,
        timeframe: Timeframe,
        riskReward: Double = 2.0
    ): TradeSetup? {
        val setup = engine.analyze(symbol, name, candles, timeframe, riskReward) ?: return null
        db.signalDao().insert(setup.toEntity())
        return setup
    }

    suspend fun updateResult(id: String, result: TradeResult, exitPrice: Double?, pnl: Double?) {
        val existing = db.signalDao().getOpenSignals().find { it.id == id } ?: return
        db.signalDao().update(
            existing.copy(
                result = result.name,
                exitPrice = exitPrice,
                pnl = pnl,
                closedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun getPerformanceByStrategy(): List<com.tradesignal.ai.data.model.StrategyPerformance> {
        val strategies = db.signalDao().getStrategies()
        return strategies.map { name ->
            val trades = db.signalDao().getByStrategy(name)
                .filter { it.result != TradeResult.OPEN.name }
            val wins = trades.count { it.result == TradeResult.WIN.name }
            val losses = trades.count { it.result == TradeResult.LOSS.name }
            val total = trades.size
            val winRate = if (total > 0) wins.toDouble() / total * 100 else 0.0
            val avgWin = trades.filter { it.pnl != null && it.pnl > 0 }.mapNotNull { it.pnl }.average().takeIf { !it.isNaN() } ?: 0.0
            val avgLoss = trades.filter { it.pnl != null && it.pnl < 0 }.mapNotNull { it.pnl }.average().takeIf { !it.isNaN() } ?: 0.0
            val grossProfit = trades.filter { (it.pnl ?: 0.0) > 0 }.sumOf { it.pnl ?: 0.0 }
            val grossLoss = abs(trades.filter { (it.pnl ?: 0.0) < 0 }.sumOf { it.pnl ?: 0.0 })
            val pf = if (grossLoss > 0) grossProfit / grossLoss else 0.0
            val net = trades.sumOf { it.pnl ?: 0.0 }
            // Simple max DD approximation
            var peak = 0.0
            var maxDd = 0.0
            var equity = 0.0
            trades.sortedBy { it.timestamp }.forEach {
                equity += it.pnl ?: 0.0
                if (equity > peak) peak = equity
                val dd = if (peak > 0) (peak - equity) / peak * 100 else 0.0
                if (dd > maxDd) maxDd = dd
            }
            com.tradesignal.ai.data.model.StrategyPerformance(
                strategyName = name,
                totalTrades = total,
                wins = wins,
                losses = losses,
                winRate = winRate,
                profitFactor = pf,
                maxDrawdownPercent = maxDd,
                netPnl = net,
                avgWin = avgWin,
                avgLoss = avgLoss
            )
        }
    }

    private fun abs(v: Double) = if (v < 0) -v else v

    private fun SignalEntity.toSetup() = TradeSetup(
        id = id,
        symbol = symbol,
        name = name,
        timeframe = Timeframe.valueOf(timeframe),
        signal = SignalType.valueOf(signal),
        entry = entry,
        stopLoss = stopLoss,
        target1 = target1,
        target2 = target2,
        riskReward = riskReward,
        setupScore = setupScore,
        strategyName = strategyName,
        timestamp = timestamp,
        reason = reason,
        indicators = com.tradesignal.ai.data.model.IndicatorValues(),
        trend = com.tradesignal.ai.data.model.Trend.valueOf(trend),
        riskLevel = riskLevel,
        isDemo = true
    )

    private fun TradeSetup.toEntity() = SignalEntity(
        id = id,
        symbol = symbol,
        name = name,
        timeframe = timeframe.name,
        signal = signal.name,
        entry = entry,
        stopLoss = stopLoss,
        target1 = target1,
        target2 = target2,
        riskReward = riskReward,
        setupScore = setupScore,
        strategyName = strategyName,
        timestamp = timestamp,
        reason = reason,
        trend = trend.name,
        riskLevel = riskLevel
    )
}
