package com.tradesignal.ai.data.model

import androidx.compose.ui.graphics.Color
import com.tradesignal.ai.ui.theme.BuyGreen
import com.tradesignal.ai.ui.theme.NeutralGray
import com.tradesignal.ai.ui.theme.SellRed
import com.tradesignal.ai.ui.theme.WatchYellow

enum class SignalType {
    BUY, SELL, WATCH, NONE;

    fun color(): Color = when (this) {
        BUY -> BuyGreen
        SELL -> SellRed
        WATCH -> WatchYellow
        NONE -> NeutralGray
    }

    fun displayName(): String = when (this) {
        BUY -> "BUY"
        SELL -> "SELL"
        WATCH -> "WATCH"
        NONE -> "—"
    }
}

enum class Trend {
    BULLISH, BEARISH, SIDEWAYS;

    fun displayName(): String = when (this) {
        BULLISH -> "Bullish"
        BEARISH -> "Bearish"
        SIDEWAYS -> "Sideways"
    }

    fun color(): Color = when (this) {
        BULLISH -> BuyGreen
        BEARISH -> SellRed
        SIDEWAYS -> NeutralGray
    }
}

enum class Timeframe(val label: String, val minutes: Int) {
    M1("1m", 1),
    M5("5m", 5),
    M15("15m", 15),
    H1("1H", 60),
    D1("1D", 1440)
}

enum class TradeResult {
    OPEN, WIN, LOSS, BREAKEVEN, EXPIRED
}

data class Ohlcv(
    val timestamp: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double
)

data class Instrument(
    val symbol: String,
    val name: String,
    val type: InstrumentType = InstrumentType.STOCK,
    val exchange: String = "NSE"
)

enum class InstrumentType {
    INDEX, STOCK, ETF
}

data class MarketQuote(
    val symbol: String,
    val name: String,
    val price: Double,
    val change: Double,
    val changePercent: Double,
    val trend: Trend,
    val signal: SignalType,
    val signalStrength: Int, // 0-100 setup quality
    val high: Double = price,
    val low: Double = price,
    val volume: Double = 0.0,
    val isDemo: Boolean = true
)

data class IndicatorValues(
    val ema9: Double? = null,
    val ema20: Double? = null,
    val ema50: Double? = null,
    val ema200: Double? = null,
    val rsi: Double? = null,
    val macdLine: Double? = null,
    val macdSignal: Double? = null,
    val macdHistogram: Double? = null,
    val vwap: Double? = null,
    val bbUpper: Double? = null,
    val bbMiddle: Double? = null,
    val bbLower: Double? = null,
    val atr: Double? = null,
    val volumeAvg: Double? = null,
    val support: Double? = null,
    val resistance: Double? = null
)

data class TradeSetup(
    val id: String,
    val symbol: String,
    val name: String,
    val timeframe: Timeframe,
    val signal: SignalType,
    val entry: Double,
    val stopLoss: Double,
    val target1: Double,
    val target2: Double,
    val riskReward: Double,
    val setupScore: Int, // 0-100 quality score
    val strategyName: String,
    val timestamp: Long,
    val reason: String,
    val indicators: IndicatorValues,
    val trend: Trend,
    val riskLevel: String, // Low / Medium / High
    val isDemo: Boolean = true
)

data class BacktestConfig(
    val symbol: String,
    val timeframe: Timeframe,
    val startDate: Long,
    val endDate: Long,
    val strategyName: String,
    val riskReward: Double = 2.0,
    val riskPercent: Double = 1.0
)

data class BacktestResult(
    val config: BacktestConfig,
    val totalTrades: Int,
    val winningTrades: Int,
    val losingTrades: Int,
    val winRate: Double,
    val averageWin: Double,
    val averageLoss: Double,
    val profitFactor: Double,
    val maxDrawdownPercent: Double,
    val netPnl: Double,
    val consecutiveWins: Int,
    val consecutiveLosses: Int,
    val trades: List<SimulatedTrade>
)

data class SimulatedTrade(
    val entryTime: Long,
    val exitTime: Long,
    val direction: SignalType,
    val entry: Double,
    val exit: Double,
    val stopLoss: Double,
    val target: Double,
    val pnl: Double,
    val result: TradeResult,
    val barsHeld: Int
)

data class PaperPosition(
    val id: Long = 0,
    val symbol: String,
    val name: String,
    val side: SignalType, // BUY or SELL
    val quantity: Int,
    val entryPrice: Double,
    val currentPrice: Double,
    val stopLoss: Double?,
    val target: Double?,
    val openedAt: Long,
    val unrealizedPnl: Double,
    val unrealizedPnlPercent: Double
)

data class PaperTrade(
    val id: Long = 0,
    val symbol: String,
    val name: String,
    val side: SignalType,
    val quantity: Int,
    val entryPrice: Double,
    val exitPrice: Double,
    val stopLoss: Double?,
    val target: Double?,
    val openedAt: Long,
    val closedAt: Long,
    val pnl: Double,
    val pnlPercent: Double,
    val result: TradeResult
)

data class PaperAccount(
    val balance: Double,
    val equity: Double,
    val availableMargin: Double,
    val openPositionsValue: Double,
    val totalPnl: Double,
    val todayPnl: Double,
    val winRate: Double,
    val totalTrades: Int,
    val maxDrawdown: Double
)

data class AlertConfig(
    val id: Long = 0,
    val symbol: String,
    val type: AlertType,
    val conditionValue: Double?,
    val enabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

enum class AlertType {
    PRICE_ABOVE,
    PRICE_BELOW,
    RSI_ABOVE,
    RSI_BELOW,
    EMA_CROSSOVER,
    NEW_BUY_SETUP,
    NEW_SELL_SETUP,
    TARGET_REACHED,
    STOP_LOSS_REACHED
}

data class StrategyPerformance(
    val strategyName: String,
    val totalTrades: Int,
    val wins: Int,
    val losses: Int,
    val winRate: Double,
    val profitFactor: Double,
    val maxDrawdownPercent: Double,
    val netPnl: Double,
    val avgWin: Double,
    val avgLoss: Double
)
