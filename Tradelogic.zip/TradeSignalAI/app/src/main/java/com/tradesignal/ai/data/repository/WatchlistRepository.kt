package com.tradesignal.ai.data.repository

import com.tradesignal.ai.data.local.AppDatabase
import com.tradesignal.ai.data.local.WatchlistEntity
import com.tradesignal.ai.data.model.Instrument
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class WatchlistRepository(private val db: AppDatabase) {

    fun getWatchlist(): Flow<List<Instrument>> {
        return db.watchlistDao().getAll().map { list ->
            list.map {
                Instrument(
                    symbol = it.symbol,
                    name = it.name,
                    type = try {
                        com.tradesignal.ai.data.model.InstrumentType.valueOf(it.type)
                    } catch (_: Exception) {
                        com.tradesignal.ai.data.model.InstrumentType.STOCK
                    }
                )
            }
        }
    }

    suspend fun add(instrument: Instrument) {
        db.watchlistDao().insert(
            WatchlistEntity(
                symbol = instrument.symbol,
                name = instrument.name,
                type = instrument.type.name
            )
        )
    }

    suspend fun remove(symbol: String) {
        db.watchlistDao().delete(symbol)
    }

    suspend fun count(): Int = db.watchlistDao().count()
}
