package com.tradesignal.ai.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface OhlcvDao {
    @Query("SELECT * FROM ohlcv WHERE symbol = :symbol AND timeframe = :timeframe ORDER BY timestamp ASC")
    suspend fun getCandles(symbol: String, timeframe: String): List<OhlcvEntity>

    @Query("SELECT * FROM ohlcv WHERE symbol = :symbol AND timeframe = :timeframe AND timestamp BETWEEN :start AND :end ORDER BY timestamp ASC")
    suspend fun getCandlesInRange(symbol: String, timeframe: String, start: Long, end: Long): List<OhlcvEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(candles: List<OhlcvEntity>)

    @Query("DELETE FROM ohlcv WHERE symbol = :symbol AND timeframe = :timeframe")
    suspend fun deleteForSymbol(symbol: String, timeframe: String)

    @Query("SELECT COUNT(*) FROM ohlcv WHERE symbol = :symbol")
    suspend fun countForSymbol(symbol: String): Int
}

@Dao
interface SignalDao {
    @Query("SELECT * FROM signals ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentSignals(limit: Int = 50): Flow<List<SignalEntity>>

    @Query("SELECT * FROM signals WHERE symbol = :symbol ORDER BY timestamp DESC")
    fun getSignalsForSymbol(symbol: String): Flow<List<SignalEntity>>

    @Query("SELECT * FROM signals WHERE result = 'OPEN'")
    suspend fun getOpenSignals(): List<SignalEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(signal: SignalEntity)

    @Update
    suspend fun update(signal: SignalEntity)

    @Query("SELECT * FROM signals WHERE strategyName = :strategy")
    suspend fun getByStrategy(strategy: String): List<SignalEntity>

    @Query("SELECT DISTINCT strategyName FROM signals")
    suspend fun getStrategies(): List<String>
}

@Dao
interface WatchlistDao {
    @Query("SELECT * FROM watchlist ORDER BY addedAt DESC")
    fun getAll(): Flow<List<WatchlistEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: WatchlistEntity)

    @Query("DELETE FROM watchlist WHERE symbol = :symbol")
    suspend fun delete(symbol: String)

    @Query("SELECT COUNT(*) FROM watchlist")
    suspend fun count(): Int
}

@Dao
interface PaperAccountDao {
    @Query("SELECT * FROM paper_account WHERE id = 1")
    fun getAccount(): Flow<PaperAccountEntity?>

    @Query("SELECT * FROM paper_account WHERE id = 1")
    suspend fun getAccountOnce(): PaperAccountEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(account: PaperAccountEntity)

    @Update
    suspend fun update(account: PaperAccountEntity)
}

@Dao
interface PaperPositionDao {
    @Query("SELECT * FROM paper_positions")
    fun getAll(): Flow<List<PaperPositionEntity>>

    @Query("SELECT * FROM paper_positions")
    suspend fun getAllOnce(): List<PaperPositionEntity>

    @Insert
    suspend fun insert(position: PaperPositionEntity): Long

    @Query("DELETE FROM paper_positions WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("SELECT * FROM paper_positions WHERE id = :id")
    suspend fun getById(id: Long): PaperPositionEntity?
}

@Dao
interface PaperTradeDao {
    @Query("SELECT * FROM paper_trades ORDER BY closedAt DESC")
    fun getAll(): Flow<List<PaperTradeEntity>>

    @Query("SELECT * FROM paper_trades ORDER BY closedAt DESC")
    suspend fun getAllOnce(): List<PaperTradeEntity>

    @Insert
    suspend fun insert(trade: PaperTradeEntity): Long

    @Query("SELECT COUNT(*) FROM paper_trades")
    suspend fun count(): Int
}

@Dao
interface AlertDao {
    @Query("SELECT * FROM alerts WHERE enabled = 1")
    fun getActive(): Flow<List<AlertEntity>>

    @Query("SELECT * FROM alerts")
    fun getAll(): Flow<List<AlertEntity>>

    @Insert
    suspend fun insert(alert: AlertEntity): Long

    @Update
    suspend fun update(alert: AlertEntity)

    @Query("DELETE FROM alerts WHERE id = :id")
    suspend fun delete(id: Long)
}

@Dao
interface SettingsDao {
    @Query("SELECT * FROM user_settings WHERE id = 1")
    fun getSettings(): Flow<UserSettingsEntity?>

    @Query("SELECT * FROM user_settings WHERE id = 1")
    suspend fun getSettingsOnce(): UserSettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(settings: UserSettingsEntity)
}
