# Building Tradelogic

## Prerequisites

1. Install **Android Studio** (Hedgehog or newer recommended).
2. Install **JDK 17**.
3. In Android Studio → SDK Manager, install:
   - Android SDK Platform 34
   - Android SDK Build-Tools 34.x
   - Android Emulator (optional)

## Open & Sync

1. File → Open → select the `TradeSignalAI` folder.
2. Allow Gradle to download dependencies (requires internet).
3. If prompted, accept the Android SDK license.

## Run Debug

- Select a device/emulator.
- Click **Run** (green triangle) or `Shift+F10`.
- First launch seeds demo OHLCV data (takes a few seconds).

## Generate Debug APK

```bash
cd TradeSignalAI
./gradlew assembleDebug
```

APK location:

```
app/build/outputs/apk/debug/app-debug.apk
```

(If `gradlew` is missing the binary jar, use Android Studio’s built-in Gradle or run `gradle wrapper` after installing Gradle.)

## Release Build

1. Create a keystore (or use existing).
2. Configure signing in `app/build.gradle.kts` or via Android Studio **Generate Signed Bundle / APK**.
3. `./gradlew bundleRelease` for Play Store AAB.

## Notes

- No paid server required for paper trading or backtesting.
- Live market data is **not** connected in v1. All prices are demo/synthetic and clearly labeled.
- To connect a licensed data provider later, implement the remote side of `MarketDataRepository`.
