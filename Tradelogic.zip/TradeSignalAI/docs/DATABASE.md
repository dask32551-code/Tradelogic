# Database Schema

Room database: `tradesignal_ai.db` (version 1)

## Tables

### ohlcv
| Column | Type | Notes |
|--------|------|-------|
| id | Long PK auto | |
| symbol | String | |
| timeframe | String | M1, M5, M15, H1, D1 |
| timestamp | Long | epoch ms |
| open, high, low, close, volume | Double | |

### signals
| Column | Type | Notes |
|--------|------|-------|
| id | String PK | UUID |
| symbol, name, timeframe | String | |
| signal | String | BUY / SELL / WATCH |
| entry, stopLoss, target1, target2 | Double | |
| riskReward | Double | |
| setupScore | Int | 0–100 |
| strategyName | String | |
| timestamp | Long | |
| reason | String | |
| trend, riskLevel | String | |
| result | String | OPEN / WIN / LOSS / BREAKEVEN / EXPIRED |
| exitPrice, pnl, closedAt | nullable | |

### watchlist
symbol (PK), name, type, addedAt

### paper_account
id=1, balance, initialBalance, createdAt

### paper_positions
id, symbol, name, side, quantity, entryPrice, stopLoss, target, openedAt

### paper_trades
id, symbol, name, side, quantity, entryPrice, exitPrice, stopLoss, target, openedAt, closedAt, pnl, result

### alerts
id, symbol, type, conditionValue, enabled, createdAt

### user_settings
id=1, preferredRiskReward, riskPercent, isPremium, defaultTimeframe
