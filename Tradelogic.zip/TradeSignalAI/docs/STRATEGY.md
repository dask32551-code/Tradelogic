# Strategy Documentation — Tradelogic

## Multi-Indicator Confluence Strategy

Signals are generated only when multiple independent technical conditions align.

### Indicators Used

| Indicator | Period / Settings | Role |
|-----------|-------------------|------|
| EMA 9 / 20 / 50 / 200 | Standard | Trend structure |
| RSI | 14 | Momentum / overbought-oversold |
| MACD | 12, 26, 9 | Momentum confirmation |
| VWAP | Session cumulative | Institutional reference |
| Bollinger Bands | 20, 2σ | Volatility extremes |
| ATR | 14 | Volatility for stops |
| Volume vs SMA 20 | — | Confirmation |
| Swing High / Low | ~8–10 bars | Stop placement |
| Support / Resistance | 50-bar lookback | Context |

### Setup Quality Score (0–100)

The score is a **quality / confluence score**, **not** a probability of profit.

Baseline: 50 (neutral).

| Factor | Points |
|--------|--------|
| EMA stack bullish + price > EMA20 | +15 |
| EMA stack bearish + price < EMA20 | −15 |
| RSI in healthy bullish zone | +12 |
| RSI in healthy bearish zone | −12 |
| RSI overbought / oversold | −8 / +8 |
| MACD positive / negative | ±12 |
| Volume above average | +10 |
| Volume weak | −5 |
| Price vs VWAP | ±8 |
| Bollinger position | ±5 |

Final score is clamped to 0–100.

### Signal Mapping

- **Score ≥ 70** → BUY
- **Score ≤ 30** → SELL
- **Score 40–60** → WATCH
- Otherwise → no signal

### Entry, Stop Loss, Targets

- **Entry**: current close of the analysis bar.
- **Stop Loss**: recent swing low (BUY) or swing high (SELL), fallback ATR × 1.5.
- **Target 1**: Entry ± (risk × 0.6 × R:R)
- **Target 2**: Entry ± (risk × R:R)

User-selectable R:R: 1:1, 1:1.5, 1:2, 1:3 (default 1:2).

### Explanation Panel

Every setup includes a human-readable reason built from the actual contributing factors and indicator values.

### What the App Never Claims

- Guaranteed profit
- 100% accuracy
- That targets will be hit
- That the quality score is a win-probability
