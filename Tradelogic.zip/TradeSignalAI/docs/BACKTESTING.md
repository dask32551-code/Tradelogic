# Backtesting Documentation

## Overview

The backtest engine runs entirely on-device using historical or demo OHLCV stored in Room.

All results are **historical / simulated**. They do not predict future performance.

## Configuration

- Instrument (symbol)
- Timeframe (currently Daily for demo depth)
- Date range (derived from available candles)
- Strategy name
- Risk/Reward ratio (default 2.0)

## Execution Logic

1. Warm-up period (~50 bars) for indicator stability.
2. At each bar, run the Multi-Indicator Confluence strategy on the window.
3. On BUY or SELL signal:
   - Place entry at signal bar close.
   - Set stop and target from the strategy.
   - Walk forward bar-by-bar (max 40 bars).
   - Exit on stop, target, or time expiry.
4. Record SimulatedTrade (entry/exit, pnl, result, bars held).
5. Aggregate statistics.

## Reported Metrics

- Total trades
- Winning / Losing trades
- Win rate (%)
- Average win / Average loss
- Profit factor
- Maximum drawdown (%)
- Net simulated P&L (in price points)
- Max consecutive wins / losses

## Limitations

- Demo data is synthetic (random-walk style). Real CSV imports produce more meaningful results.
- No slippage or commission modelling in v1.
- One strategy only in v1 (extensible).
- Forward-looking bias is minimized by using only past data for each decision.

## Usage

From the Backtest screen: select instrument → Run Backtest. Results appear immediately.
