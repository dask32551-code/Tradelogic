# Tradelogic

**AI-assisted trading analysis, signal generation & paper-trading platform for Android.**

> **Important:** This application provides market analysis and simulated trading tools for **informational and educational purposes only**. Trading involves substantial risk of loss. Signals are probabilistic. Past or simulated performance does **not** guarantee future results. Never risk money you cannot afford to lose.

## Features

- **Dashboard** — Indices (NIFTY, BANK NIFTY, Sensex), popular stocks, top setups, paper P&L
- **Top Setups** — BUY / SELL / WATCH with Entry, Stop Loss, Targets, Risk/Reward, Setup Quality Score (0–100)
- **Technical Engine** — EMA 9/20/50/200, RSI, MACD, VWAP, Bollinger Bands, ATR, Volume, Support/Resistance
- **Signal Generation** — Multi-indicator confluence score (quality score, **not** profit probability)
- **Backtesting** — Local engine on historical/demo OHLCV; win rate, profit factor, max drawdown, etc.
- **Paper Trading** — ₹10,00,000 virtual balance; open/close positions; P&L tracking
- **Strategy Performance** — Calculated from actual signal & trade records (not hard-coded)
- **Watchlist, Alerts (framework), Charts-ready architecture**
- **Dark professional UI** with bottom navigation
- **Demo / Paper Data** clearly labeled — no fabricated live prices

## Architecture

```
UI (Compose)
  ↓
Repositories
  ↓
Domain: IndicatorCalculator · StrategyEngine · BacktestEngine · PaperTradingEngine
  ↓
Room Database (local) + Demo data generator
```

Market-data providers can be swapped later via the `MarketDataRepository` without changing UI or strategy code.

## Requirements

- Android Studio Hedgehog (2023.1.1) or newer
- JDK 17
- Android SDK 34
- Min SDK 26

## Build Instructions

1. Open the project in Android Studio.
2. Let Gradle sync (internet required for dependencies).
3. Run on emulator or device (Debug).

### Debug APK

```bash
./gradlew assembleDebug
# Output: app/build/outputs/apk/debug/app-debug.apk
```

### Release AAB / APK

```bash
./gradlew assembleRelease   # or bundleRelease for AAB
```

Sign with your keystore for Play Store distribution.

## Demo Data

On first launch the app generates realistic synthetic OHLCV for NIFTY, BANKNIFTY, Sensex and popular NSE stocks. All screens show a **Demo / Paper Data** banner.

You can import your own historical CSV (timestamp,open,high,low,close,volume) via `MarketDataRepository.importCsv(...)`.

## Documentation

- Strategy: `docs/STRATEGY.md`
- Backtesting: `docs/BACKTESTING.md`
- Database: `docs/DATABASE.md`

## Monetization (prepared)

- **Free**: limited watchlist, basic paper trades, basic indicators, ads (never over charts or active analysis).
- **Premium** (planned): no ads, advanced strategies, more alerts, advanced analytics.

## Risk & Compliance

If you later offer this as regulated investment/trading advice in India, obtain appropriate professional and legal guidance before launch.

## License

Proprietary — All rights reserved. For educational/demo use.

## Data source: Yahoo Finance (delayed)

Market data now comes from the free Yahoo Finance chart endpoint (no API key).
- Symbol mapping: `NIFTY→^NSEI`, `BANKNIFTY→^NSEBANK`, `SENSEX→^BSESN`, stocks → `SYMBOL.NS` (see `data/remote/YahooFinanceClient.kt`).
- Cache: candles are stored in Room and refreshed only when older than a TTL (1m: 1 min, 5m: 2 min, 15m: 5 min, 1H: 10 min, 1D: 15 min). Failed fetches back off for 60 s.
- Labels: header pill shows `DELAYED`, `PARTIAL LIVE` or `DEMO DATA` (offline fallback).
- Prices are ~15 min delayed and the endpoint is unofficial. Not for live execution; test with paper trading first.
